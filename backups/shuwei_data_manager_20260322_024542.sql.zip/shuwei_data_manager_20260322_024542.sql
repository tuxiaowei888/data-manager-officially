-- 数据库备份: shuwei_data_manager
-- 备份时间: 2026-03-22 02:45:42
-- ==========================================================


-- 表: ai_configs
DROP TABLE IF EXISTS `ai_configs`;
CREATE TABLE `ai_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置名称',
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'AI提供商',
  `api_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'API密钥',
  `api_base_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'API基础URL',
  `model_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模型名称',
  `temperature` float DEFAULT '0.7' COMMENT '温度参数',
  `max_tokens` int DEFAULT '4096' COMMENT '最大token数',
  `system_prompt` text COLLATE utf8mb4_unicode_ci COMMENT '系统提示词',
  `report_prompt_template` text COLLATE utf8mb4_unicode_ci COMMENT '报告生成提示词模板',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否默认配置',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ai_configs` VALUES (1, '数维数据管家AI', 'deepseek', 'sk-e691d10d12e749709f4cb54fab224f0d', 'https://api.deepseek.com/v1', '数维数据管家AI', 1.0, 4096, '# 你是数维数据管家系统的AI智能诊断专家

你是"数维数据管家"系统的核心智能引擎，一位权威的数据资产评估专家。你的任务是基于企业提交的数据资产信息，结合系统规则库的量化评分和政策法规知识库，为企业生成专业、客观、可执行的数据资产诊断报告。

## 你的身份背景

### 专业资质
- 拥有10年以上数据资产管理咨询经验
- 精通数据要素市场化配置的政策法规体系
- 熟悉《数据安全法》《个人信息保护法》《企业数据资源相关会计处理暂行规定》等核心法规
- 掌握数据资产评估、财务会计、数据治理复合知识

### 法规知识库覆盖
- 《数据安全法》《个人信息保护法》
- 《企业数据资源相关会计处理暂行规定》
- 《关于构建数据基础制度更好发挥数据要素作用的意见》(数据二十条)
- 《数据资产评估指导意见》
- 各省市数据条例和数据交易相关规定

## 你的核心职责

1. **量化评分诊断**：基于规则库对数据资产8大维度进行评分
   - 合规与安全(C) - 数据安全合规能力
   - 流通能力(O) - 数据流通与交易能力
   - 管理体系(M) - 数据治理管理能力
   - 权属确认(L) - 数据确权与权责划分
   - 发展潜力(P) - 数据资产增值潜力
   - 数据质量(Q) - 数据完整性准确性
   - 成本计量(S) - 数据管理成本效益
   - 价值评估(V) - 数据资产价值评估

2. **政策依据匹配**：从知识库中检索相关政策法规作为评分依据

3. **问题诊断分析**：识别关键问题并分级（P0/P1/P2）

4. **行动建议生成**：提供具体可执行的改进建议

## 你的评估原则

| 原则 | 说明 |
|------|------|
| 专业性 | 引用具体法规条款，给出权威判断 |
| 客观性 | 基于数据和事实，不夸大不隐瞒 |
| 实用性 | 建议具体可执行，有明确行动路径 |
| 清晰性 | 用企业管理者能理解的语言表达 |
| 建设性 | 以帮助企业提升为目标导向 |

## 你的输出风格

- 语言严谨专业，但通俗易懂
- 适当使用Markdown格式增强可读性
- 在适当位置使用emoji增强视觉效果
- 报告结构清晰，层次分明
- 关键数据和结论突出显示', '# 数据资产全链路智能诊断报告生成指南

## 报告基本信息
- 报告名称：《数据资产全链路智能诊断与价值实现报告》
- 报告目的：为企业提供数据资产现状诊断与提升路径
- 报告风格：专业咨询机构交付标准，严谨但有温度

## 输入数据格式

### 1. 企业基础画像
```
企业名称：{org_name}
评估时间：{generated_at}
所属行业：{industry}（用于行业对标分析）
```

### 2. 规则库量化评分（8大维度）
```
综合得分：{total_score}/100
成熟度等级：{maturity_level}（初始级/发展级/规范级/优化级/卓越级）
风险等级：{risk_level}（高/中/低）

八大维度评分详情：
{dimension_scores}

维度说明：
- 合规与安全(C)：数据安全合规、数据分类分级、隐私保护
- 流通能力(L)：数据开放共享、数据交易能力、数据流通渠道
- 管理体系(M)：数据治理架构、数据管理流程、数据质量管理
- 权属确认(O)：数据确权能力、权责划分清晰度、权益保障
- 发展潜力(P)：数据资产增值空间、创新发展能力、未来规划
- 数据质量(Q)：数据完整性、准确性、一致性、时效性
- 成本计量(S)：数据管理成本、成本效益分析、投入产出比
- 价值评估(V)：数据资产估值方法、价值实现路径、潜在收益
```

### 3. 关键问题清单（按优先级排序）
```
🔴 P0级阻断性问题（必须立即解决）：
{p0_issues}
影响：可能导致数据资产无法入表或面临监管处罚

🟡 P1级减值性问题（需要重点关注）：
{p1_issues}
影响：影响数据资产价值评估或企业数据战略实现

🟢 P2级优化建议（持续改进方向）：
{p2_issues}
影响：有助于提升数据资产管理水平和价值实现
```

### 4. 政策知识库依据
```
{knowledge_policies}
说明：系统从知识库中检索的与企业情况相关的政策法规条文
```

## 报告生成结构

请严格按照以下7个章节生成完整报告：

### 第一章：执行摘要（Executive Summary）
- **一句话核心结论**：用通俗语言概括企业数据资产现状（如："企业数据资产处于''规范级''，合规基础扎实但流通能力待提升"）
- **关键发现**：列出1-3个最重要的发现
- **核心风险**：指出最需要关注的1-2个P0/P1风险
- **总体建议**：给出最高优先级的战略方向建议
字数控制：200-300字

### 第二章：数据资产价值预测总览
- 基于当前评分和行业对标，预测企业数据资产的：
  - 当前估值范围（保守/中性/乐观）
  - 未来3-5年增值潜力
  - 与行业标杆的差距分析
- 价值实现路径建议（入表/融资/交易/自用）

### 第三章：八大维度深度分析
对每个维度进行分析：
- **评分结果**：得分与评级
- **达标情况**：是否符合监管要求或行业标准
- **问题识别**：存在的具体问题
- **政策依据**：相关的法规条款
- **改进建议**：具体的提升措施

### 第四章：关键问题详细分析
对P0/P1级问题进行深入分析：
- 问题描述与影响
- 问题成因分析
- 法规依据说明
- 解决建议与时间表

### 第五章：政策合规性对标
- 对照《数据安全法》《个人信息保护法》等法规
- 说明企业合规现状
- 指出合规差距
- 提供合规改进建议

### 第六章：数据资产管理路线图
- 短期（3-6个月）：基础建设期
- 中期（6-12个月）：能力提升期
- 长期（1-3年）：价值实现期
每个阶段包含具体行动项和预期成果

### 第七章：附录
- 评分详细说明
- 政策法规索引
- 术语解释
- 咨询建议

## 输出格式要求

1. 使用Markdown格式，便于阅读和转换
2. 关键数据用**加粗**突出
3. 适当使用emoji增强可读性（📊💼📋🔒💰📈等）
4. 表格用于对比分析
5. 列表用于步骤和清单
6. 报告总字数：3000-5000字

## 特别注意事项

1. **严格基于输入数据**：不要编造数据，所有结论必须有依据
2. **突出实用性**：每个建议必须具体可执行
3. **量化分析**：尽量用数字说明问题
4. **行业对标**：适当引用行业平均水平进行对比
5. **有温度的表达**：既要专业严谨，也要体现对企业的关怀支持', 1, 1, '2026-03-21 14:53:08', '2026-03-21 15:39:04');

-- 表: ai_prompt_templates
DROP TABLE IF EXISTS `ai_prompt_templates`;
CREATE TABLE `ai_prompt_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板类型: system/report',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '模板描述',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板内容',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '模板变量JSON数组',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否默认模板',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `sort_order` int DEFAULT '0' COMMENT '排序顺序',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ai_prompt_templates` VALUES (1, '标准诊断模板', 'system', '系统默认的AI诊断专家角色提示词', '# 你是数维数据管家系统的AI智能诊断专家

你是"数维数据管家"系统的核心智能引擎，一位权威的数据资产评估专家。你的任务是基于企业提交的数据资产信息，结合系统规则库的量化评分和政策法规知识库，为企业生成专业、客观、可执行的数据资产诊断报告。

## 你的身份背景

### 专业资质
- 拥有10年以上数据资产管理咨询经验
- 精通数据要素市场化配置的政策法规体系
- 熟悉《数据安全法》《个人信息保护法》《企业数据资源相关会计处理暂行规定》等核心法规
- 掌握数据资产评估、财务会计、数据治理复合知识

### 法规知识库覆盖
- 《数据安全法》《个人信息保护法》
- 《企业数据资源相关会计处理暂行规定》
- 《关于构建数据基础制度更好发挥数据要素作用的意见》(数据二十条)
- 《数据资产评估指导意见》
- 各省市数据条例和数据交易相关规定

## 你的核心职责

1. **量化评分诊断**：基于规则库对数据资产8大维度进行评分
   - 合规与安全(C) - 数据安全合规能力
   - 流通能力(O) - 数据流通与交易能力
   - 管理体系(M) - 数据治理管理能力
   - 权属确认(L) - 数据确权与权责划分
   - 发展潜力(P) - 数据资产增值潜力
   - 数据质量(Q) - 数据完整性准确性
   - 成本计量(S) - 数据管理成本效益
   - 价值评估(V) - 数据资产价值评估

2. **政策依据匹配**：从知识库中检索相关政策法规作为评分依据

3. **问题诊断分析**：识别关键问题并分级（P0/P1/P2）

4. **行动建议生成**：提供具体可执行的改进建议

## 你的评估原则

| 原则 | 说明 |
|------|------|
| 专业性 | 引用具体法规条款，给出权威判断 |
| 客观性 | 基于数据和事实，不夸大不隐瞒 |
| 实用性 | 建议具体可执行，有明确行动路径 |
| 清晰性 | 用企业管理者能理解的语言表达 |
| 建设性 | 以帮助企业提升为目标导向 |

## 你的输出风格

- 语言严谨专业，但通俗易懂
- 适当使用Markdown格式增强可读性
- 在适当位置使用emoji增强视觉效果
- 报告结构清晰，层次分明
- 关键数据和结论突出显示', '["org_name", "generated_at"]', 1, 1, 1, '2026-03-21 15:07:16', '2026-03-21 15:39:04'),
(2, '标准报告模板', 'report', '系统默认的报告生成提示词模板', '# 数据资产全链路智能诊断报告生成指南

## 报告基本信息
- 报告名称：《数据资产全链路智能诊断与价值实现报告》
- 报告目的：为企业提供数据资产现状诊断与提升路径
- 报告风格：专业咨询机构交付标准，严谨但有温度

## 输入数据格式

### 1. 企业基础画像
```
企业名称：{org_name}
评估时间：{generated_at}
所属行业：{industry}（用于行业对标分析）
```

### 2. 规则库量化评分（8大维度）
```
综合得分：{total_score}/100
成熟度等级：{maturity_level}（初始级/发展级/规范级/优化级/卓越级）
风险等级：{risk_level}（高/中/低）

八大维度评分详情：
{dimension_scores}

维度说明：
- 合规与安全(C)：数据安全合规、数据分类分级、隐私保护
- 流通能力(L)：数据开放共享、数据交易能力、数据流通渠道
- 管理体系(M)：数据治理架构、数据管理流程、数据质量管理
- 权属确认(O)：数据确权能力、权责划分清晰度、权益保障
- 发展潜力(P)：数据资产增值空间、创新发展能力、未来规划
- 数据质量(Q)：数据完整性、准确性、一致性、时效性
- 成本计量(S)：数据管理成本、成本效益分析、投入产出比
- 价值评估(V)：数据资产估值方法、价值实现路径、潜在收益
```

### 3. 关键问题清单（按优先级排序）
```
🔴 P0级阻断性问题（必须立即解决）：
{p0_issues}
影响：可能导致数据资产无法入表或面临监管处罚

🟡 P1级减值性问题（需要重点关注）：
{p1_issues}
影响：影响数据资产价值评估或企业数据战略实现

🟢 P2级优化建议（持续改进方向）：
{p2_issues}
影响：有助于提升数据资产管理水平和价值实现
```

### 4. 政策知识库依据
```
{knowledge_policies}
说明：系统从知识库中检索的与企业情况相关的政策法规条文
```

## 报告生成结构

请严格按照以下7个章节生成完整报告：

### 第一章：执行摘要（Executive Summary）
- **一句话核心结论**：用通俗语言概括企业数据资产现状（如："企业数据资产处于''规范级''，合规基础扎实但流通能力待提升"）
- **关键发现**：列出1-3个最重要的发现
- **核心风险**：指出最需要关注的1-2个P0/P1风险
- **总体建议**：给出最高优先级的战略方向建议
字数控制：200-300字

### 第二章：数据资产价值预测总览
- 基于当前评分和行业对标，预测企业数据资产的：
  - 当前估值范围（保守/中性/乐观）
  - 未来3-5年增值潜力
  - 与行业标杆的差距分析
- 价值实现路径建议（入表/融资/交易/自用）

### 第三章：八大维度深度分析
对每个维度进行分析：
- **评分结果**：得分与评级
- **达标情况**：是否符合监管要求或行业标准
- **问题识别**：存在的具体问题
- **政策依据**：相关的法规条款
- **改进建议**：具体的提升措施

### 第四章：关键问题详细分析
对P0/P1级问题进行深入分析：
- 问题描述与影响
- 问题成因分析
- 法规依据说明
- 解决建议与时间表

### 第五章：政策合规性对标
- 对照《数据安全法》《个人信息保护法》等法规
- 说明企业合规现状
- 指出合规差距
- 提供合规改进建议

### 第六章：数据资产管理路线图
- 短期（3-6个月）：基础建设期
- 中期（6-12个月）：能力提升期
- 长期（1-3年）：价值实现期
每个阶段包含具体行动项和预期成果

### 第七章：附录
- 评分详细说明
- 政策法规索引
- 术语解释
- 咨询建议

## 输出格式要求

1. 使用Markdown格式，便于阅读和转换
2. 关键数据用**加粗**突出
3. 适当使用emoji增强可读性（📊💼📋🔒💰📈等）
4. 表格用于对比分析
5. 列表用于步骤和清单
6. 报告总字数：3000-5000字

## 特别注意事项

1. **严格基于输入数据**：不要编造数据，所有结论必须有依据
2. **突出实用性**：每个建议必须具体可执行
3. **量化分析**：尽量用数字说明问题
4. **行业对标**：适当引用行业平均水平进行对比
5. **有温度的表达**：既要专业严谨，也要体现对企业的关怀支持', '["org_name", "total_score", "dimension_scores"]', 1, 1, 2, '2026-03-21 15:07:16', '2026-03-21 15:39:04');

-- 表: channel_user_relations
DROP TABLE IF EXISTS `channel_user_relations`;
CREATE TABLE `channel_user_relations` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '?? ID',
  `channel_id` int NOT NULL COMMENT '?? ID',
  `user_id` int NOT NULL COMMENT '?? ID',
  `relation_type` enum('direct','indirect') DEFAULT 'direct' COMMENT '??????',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '????',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_channel_user` (`channel_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `channel_user_relations_ibfk_1` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_user_relations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='???????';

INSERT INTO `channel_user_relations` VALUES (1, 1, 2, 'direct', '2026-03-12 20:30:49'),
(2, 2, 3, 'direct', '2026-03-12 20:30:49');

-- 表: channels
DROP TABLE IF EXISTS `channels`;
CREATE TABLE `channels` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'æ¸ é“ ID',
  `channel_name` varchar(100) NOT NULL COMMENT 'æ¸ é“åç§°',
  `channel_code` varchar(20) NOT NULL COMMENT 'æŽ¨èç ï¼ˆå”¯ä¸€ï¼‰',
  `contact_person` varchar(50) DEFAULT NULL COMMENT 'è”ç³»äºº',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT 'è”ç³»ç”µè¯',
  `referred_users_count` int DEFAULT '0' COMMENT 'æŽ¨èç”¨æˆ·æ€»æ•°',
  `is_active` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `remark` text COMMENT 'å¤‡æ³¨',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `channel_code` (`channel_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `channels` VALUES (1, '????', 'OFFICIAL', '?????', '13800000000', 1, 1, '????', '2026-03-12 20:30:49', '2026-03-12 20:30:49'),
(2, '???? A', 'PARTNER_A', '??', '13800000001', 1, 1, '??????', '2026-03-12 20:30:49', '2026-03-12 20:30:49'),
(3, '???? B', 'PARTNER_B', '??', '13800000002', 0, 1, '??????', '2026-03-12 20:30:49', '2026-03-12 20:30:49');

-- 表: evaluation_results
DROP TABLE IF EXISTS `evaluation_results`;
CREATE TABLE `evaluation_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL COMMENT '?? ID',
  `report_id` varchar(100) NOT NULL,
  `org_name` varchar(200) NOT NULL,
  `total_score` decimal(5,2) DEFAULT NULL,
  `maturity_level` varchar(50) DEFAULT NULL,
  `compliance_score` decimal(5,2) DEFAULT NULL,
  `quality_score` decimal(5,2) DEFAULT NULL,
  `rights_score` decimal(5,2) DEFAULT NULL,
  `value_score` decimal(5,2) DEFAULT NULL,
  `cost_score` decimal(5,2) DEFAULT NULL,
  `p0_issues` json DEFAULT NULL,
  `p1_issues` json DEFAULT NULL,
  `p2_issues` json DEFAULT NULL,
  `report_data` json DEFAULT NULL,
  `report_pdf_url` varchar(500) DEFAULT NULL COMMENT 'PDF ??????',
  `report_word_url` varchar(500) DEFAULT NULL COMMENT 'Word ??????',
  `generated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '????',
  `risk_level` varchar(10) DEFAULT NULL,
  `engine_version` varchar(50) DEFAULT 'v1_static',
  `ai_analysis_log` json DEFAULT NULL,
  `detail_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_id` (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `evaluation_results` VALUES (2, 4, 'RPT660890B653B4', '12', '79.90', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-14 15:15:48', 0, 'P2', 'v1_rule_based', '{"error": "Illegal header value b''Bearer ''", "model": null, "enabled": false, "analysis": null, "provider": null, "p0_issues": [], "p1_issues": [], "p2_issues": [], "full_report": null, "recommendations": null}', '{"form_data": {"ip_work": "0", "remarks": "", "revenue": "<5000 万", "location": "四川省 - 成都市", "org_name": "12", "org_type": "企业机构", "data_type": ["用户与市场数据", "科研与公共服务数据"], "dept_name": "", "ip_patent": "0", "user_auth": "有明确隐私协议且单独同意", "cost_input": "12", "staff_size": "50 人及以下", "data_format": ["JSON/XML"], "data_policy": "是 (有正式发文)", "data_source": ["内部系统", "用户自主提供"], "originality": "高 (有核心算法/模型/独特加工)", "pain_points": ["数据定价困难", "市场需求不确定"], "rights_cert": ["政府授权运营书", "数据资产登记证书"], "completeness": "75", "contact_name": "涂晓伟", "data_concept": "非常了解", "data_encrypt": "是 (传输/存储均加密)", "data_product": ["研究报告", "数字 IP/可视化内容"], "ip_copyright": "0", "ip_trademark": "1", "service_time": "1 个月内", "asset_purpose": ["融资贷款", "交易流通"], "contact_email": "tuxiaowei520@163.com", "contact_phone": "13982274410", "has_data_dept": "否", "security_cert": ["等保三级"], "cloud_provider": "", "org_type_other": "", "sensitive_data": "已脱敏/匿名化 (不可复原)", "commercial_plan": "是 (已有实践)", "cost_accounting": "有独立项目核算", "data_type_other": "", "needed_services": ["入表辅导", "法律咨询服务"], "contact_position": "总经理", "data_volume_size": "10GB-100GB", "expected_revenue": "111", "storage_location": "自有服务器", "training_willing": "是", "update_frequency": "实时", "data_format_other": "", "data_source_other": "", "pain_points_other": "", "rights_cert_other": "", "compliance_history": "无", "data_product_other": "", "data_volume_records": "100 万 -1000 万", "security_cert_other": "", "application_scenario": ["产品优化", "政府决策"], "needed_services_other": "", "application_scenario_other": ""}, "p0_issues": [], "p1_issues": [], "p2_issues": [], "dimensions": [{"code": "C", "name": "合规与安全", "level": "良好", "logic": "底线稳固：已通过安全认证；敏感数据已完成脱敏；拥有完整的用户隐私协议。", "score": 96.8, "weight": 25, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "L", "name": "流通能力", "level": "良好", "logic": "表现良好", "score": 75.5, "weight": 10, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "M", "name": "管理体系", "level": "待提升", "logic": "有待提升", "score": 74.5, "weight": 15, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "O", "name": "权属确认", "level": "良好", "logic": "双证齐全：已获得数据资产登记证书和数据知识产权登记证书。", "score": 82.9, "weight": 15, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "P", "name": "发展潜力", "level": "待提升", "logic": "有待提升", "score": 70.5, "weight": 10, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "Q", "name": "数据质量", "level": "良好", "logic": "质量系数高：数据完整性高，实时性强，一致性校验通过。", "score": 84.3, "weight": 20, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "S", "name": "成本计量", "level": "良好", "logic": "成本核算清晰：有独立项目核算，成本分摊逻辑明确。", "score": 77.5, "weight": 10, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "V", "name": "价值评估", "level": "待提升", "logic": "场景匹配度中等：存在一定应用价值，建议拓展更多场景。", "score": 64.3, "weight": 20, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}], "rule_results": [{"score": 100.0, "weight": 5.0, "rule_id": 1, "rule_name": "数据来源合规性", "dimension_code": "C", "risk_threshold": 60.0}, {"score": 100.0, "weight": 5.0, "rule_id": 2, "rule_name": "敏感数据处理", "dimension_code": "C", "risk_threshold": 60.0}, {"score": 100.0, "weight": 4.0, "rule_id": 3, "rule_name": "数据安全措施", "dimension_code": "C", "risk_threshold": 55.0}, {"score": 100.0, "weight": 3.0, "rule_id": 4, "rule_name": "隐私政策合规", "dimension_code": "C", "risk_threshold": 50.0}, {"score": 100.0, "weight": 4.0, "rule_id": 5, "rule_name": "数据跨境传输", "dimension_code": "C", "risk_threshold": 60.0}, {"score": 100.0, "weight": 4.0, "rule_id": 6, "rule_name": "数据留存管理", "dimension_code": "C", "risk_threshold": 50.0}, {"score": 70.0, "weight": 3.0, "rule_id": 7, "rule_name": "安全认证情况", "dimension_code": "C", "risk_threshold": 50.0}, {"score": 70.0, "weight": 4.0, "rule_id": 26, "rule_name": "数据共享能力", "dimension_code": "L", "risk_threshold": 45.0}, {"score": 100.0, "weight": 4.0, "rule_id": 27, "rule_name": "API服务能力", "dimension_code": "L", "risk_threshold": 45.0}, {"score": 50.0, "weight": 3.0, "rule_id": 28, "rule_name": "数据交易记录", "dimension_code": "L", "risk_threshold": 40.0}, {"score": 70.0, "weight": 4.0, "rule_id": 23, "rule_name": "数据治理组织", "dimension_code": "M", "risk_threshold": 50.0}, {"score": 60.0, "weight": 4.0, "rule_id": 24, "rule_name": "数据管理制度", "dimension_code": "M", "risk_threshold": 50.0}, {"score": 100.0, "weight": 3.0, "rule_id": 25, "rule_name": "数据质量监控", "dimension_code": "M", "risk_threshold": 45.0}, {"score": 100.0, "weight": 5.0, "rule_id": 12, "rule_name": "数据权属确认", "dimension_code": "O", "risk_threshold": 60.0}, {"score": 70.0, "weight": 3.0, "rule_id": 13, "rule_name": "使用权界定", "dimension_code": "O", "risk_threshold": 45.0}, {"score": 100.0, "weight": 3.0, "rule_id": 14, "rule_name": "收益权分配", "dimension_code": "O", "risk_threshold": 45.0}, {"score": 50.0, "weight": 3.0, "rule_id": 15, "rule_name": "数据独创性评估", "dimension_code": "O", "risk_threshold": 50.0}, {"score": 80.0, "weight": 4.0, "rule_id": 29, "rule_name": "数据增长趋势", "dimension_code": "P", "risk_threshold": 45.0}, {"score": 50.0, "weight": 4.0, "rule_id": 30, "rule_name": "技术创新能力", "dimension_code": "P", "risk_threshold": 45.0}, {"score": 85.0, "weight": 3.0, "rule_id": 31, "rule_name": "市场拓展空间", "dimension_code": "P", "risk_threshold": 40.0}, {"score": 100.0, "weight": 4.0, "rule_id": 8, "rule_name": "数据质量管理", "dimension_code": "Q", "risk_threshold": 50.0}, {"score": 75.0, "weight": 4.0, "rule_id": 9, "rule_name": "元数据完整性", "dimension_code": "Q", "risk_threshold": 50.0}, {"score": 90.0, "weight": 3.0, "rule_id": 10, "rule_name": "数据标准化程度", "dimension_code": "Q", "risk_threshold": 45.0}, {"score": 70.0, "weight": 3.0, "rule_id": 11, "rule_name": "数据类型多样性", "dimension_code": "Q", "risk_threshold": 45.0}, {"score": 100.0, "weight": 3.0, "rule_id": 20, "rule_name": "合规成本核算", "dimension_code": "S", "risk_threshold": 45.0}, {"score": 51.2, "weight": 4.0, "rule_id": 21, "rule_name": "存储成本计量", "dimension_code": "S", "risk_threshold": 50.0}, {"score": 90.0, "weight": 3.0, "rule_id": 22, "rule_name": "运维成本统计", "dimension_code": "S", "risk_threshold": 45.0}, {"score": 80.0, "weight": 4.0, "rule_id": 16, "rule_name": "数据应用场景", "dimension_code": "V", "risk_threshold": 45.0}, {"score": 70.0, "weight": 4.0, "rule_id": 17, "rule_name": "数据价值评估", "dimension_code": "V", "risk_threshold": 50.0}, {"score": 70.0, "weight": 3.0, "rule_id": 18, "rule_name": "数据变现能力", "dimension_code": "V", "risk_threshold": 40.0}, {"score": 30.0, "weight": 3.0, "rule_id": 19, "rule_name": "数据规模价值", "dimension_code": "V", "risk_threshold": 45.0}]}', '2026-03-14 15:15:48'),
(3, 4, 'RPT67C4D7EAD68C', '测试2', '75.60', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-14 22:50:40', 0, 'P2', 'v1_rule_based', '{"error": "Illegal header value b''Bearer ''", "model": null, "enabled": false, "analysis": null, "provider": null, "p0_issues": [], "p1_issues": [{"basis": "违反成本可计量性要求", "title": "成本归集缺失", "problem": "未建立数据资源专项成本核算科目", "consequence": "入表时难以准确计量初始成本，增加审计难度"}], "p2_issues": [], "full_report": null, "recommendations": null}', '{"form_data": {"ip_work": "1", "remarks": "", "revenue": "5000 万 -2 亿", "location": "山东省 - 聊城市", "org_name": "测试2", "org_type": "事业单位", "data_type": ["用户与市场数据", "科研与公共服务数据"], "dept_name": "", "ip_patent": "1", "user_auth": "有概括性协议", "cost_input": "333", "staff_size": "50 人及以下", "data_format": ["关系型数据库"], "data_policy": "否", "data_source": ["内部系统", "用户自主提供"], "originality": "中 (有整理汇编)", "pain_points": ["法律合规风险", "数据定价困难"], "rights_cert": ["数据知识产权登记证书"], "completeness": "70", "contact_name": "涂晓伟", "data_concept": "非常了解", "data_encrypt": "否", "data_product": ["数据算法模型", "研究报告"], "ip_copyright": "1", "ip_trademark": "1", "service_time": "3 个月内", "asset_purpose": ["作价入股", "项目申报"], "contact_email": "tuxiaowei520@163.com", "contact_phone": "13982274410", "has_data_dept": "否", "security_cert": ["无"], "cloud_provider": "", "org_type_other": "", "sensitive_data": "加密存储", "commercial_plan": "是 (已有实践)", "cost_accounting": "有部分分摊", "data_type_other": "", "needed_services": ["登记代理服务", "数据合规评估"], "contact_position": "总经理", "data_volume_size": "100GB-1TB", "expected_revenue": "333", "storage_location": "自有服务器", "training_willing": "否", "update_frequency": "月级", "data_format_other": "", "data_source_other": "", "pain_points_other": "", "rights_cert_other": "", "compliance_history": "有过整改记录", "data_product_other": "", "data_volume_records": "100 万 -1000 万", "security_cert_other": "", "application_scenario": ["精准营销", "产品优化"], "needed_services_other": "", "application_scenario_other": ""}, "p0_issues": [], "p1_issues": [{"basis": "违反成本可计量性要求", "title": "成本归集缺失", "problem": "未建立数据资源专项成本核算科目", "consequence": "入表时难以准确计量初始成本，增加审计难度"}], "p2_issues": [], "dimensions": [{"code": "C", "name": "合规与安全", "level": "良好", "logic": "底线稳固：已通过安全认证；敏感数据已完成脱敏；拥有完整的用户隐私协议。", "score": 87.7, "weight": 25, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "L", "name": "流通能力", "level": "良好", "logic": "表现良好", "score": 75.5, "weight": 10, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "M", "name": "管理体系", "level": "待提升", "logic": "有待提升", "score": 71.8, "weight": 15, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "O", "name": "权属确认", "level": "待提升", "logic": "有授权无凭证：虽持有授权文件，但缺失法定登记证书。", "score": 72.1, "weight": 15, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "P", "name": "发展潜力", "level": "待提升", "logic": "有待提升", "score": 63.9, "weight": 10, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "Q", "name": "数据质量", "level": "良好", "logic": "质量系数高：数据完整性高，实时性强，一致性校验通过。", "score": 80.0, "weight": 20, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "S", "name": "成本计量", "level": "良好", "logic": "成本核算清晰：有独立项目核算，成本分摊逻辑明确。", "score": 81.3, "weight": 10, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}, {"code": "V", "name": "价值评估", "level": "待提升", "logic": "场景匹配度中等：存在一定应用价值，建议拓展更多场景。", "score": 64.3, "weight": 20, "suggestions": ["建议定期开展数据资产评估，持续跟踪改进效果", "可考虑引入第三方评估机构，获得专业改进建议", "建议建立数据资产管理委员会，统筹推进各项工作"]}], "rule_results": [{"score": 85.0, "weight": 5.0, "rule_id": 1, "rule_name": "数据来源合规性", "dimension_code": "C", "risk_threshold": 60.0}, {"score": 90.0, "weight": 5.0, "rule_id": 2, "rule_name": "敏感数据处理", "dimension_code": "C", "risk_threshold": 60.0}, {"score": 85.0, "weight": 4.0, "rule_id": 3, "rule_name": "数据安全措施", "dimension_code": "C", "risk_threshold": 55.0}, {"score": 90.0, "weight": 3.0, "rule_id": 4, "rule_name": "隐私政策合规", "dimension_code": "C", "risk_threshold": 50.0}, {"score": 100.0, "weight": 4.0, "rule_id": 5, "rule_name": "数据跨境传输", "dimension_code": "C", "risk_threshold": 60.0}, {"score": 90.0, "weight": 4.0, "rule_id": 6, "rule_name": "数据留存管理", "dimension_code": "C", "risk_threshold": 50.0}, {"score": 70.0, "weight": 3.0, "rule_id": 7, "rule_name": "安全认证情况", "dimension_code": "C", "risk_threshold": 50.0}, {"score": 70.0, "weight": 4.0, "rule_id": 26, "rule_name": "数据共享能力", "dimension_code": "L", "risk_threshold": 45.0}, {"score": 100.0, "weight": 4.0, "rule_id": 27, "rule_name": "API服务能力", "dimension_code": "L", "risk_threshold": 45.0}, {"score": 50.0, "weight": 3.0, "rule_id": 28, "rule_name": "数据交易记录", "dimension_code": "L", "risk_threshold": 40.0}, {"score": 70.0, "weight": 4.0, "rule_id": 23, "rule_name": "数据治理组织", "dimension_code": "M", "risk_threshold": 50.0}, {"score": 60.0, "weight": 4.0, "rule_id": 24, "rule_name": "数据管理制度", "dimension_code": "M", "risk_threshold": 50.0}, {"score": 90.0, "weight": 3.0, "rule_id": 25, "rule_name": "数据质量监控", "dimension_code": "M", "risk_threshold": 45.0}, {"score": 70.0, "weight": 5.0, "rule_id": 12, "rule_name": "数据权属确认", "dimension_code": "O", "risk_threshold": 60.0}, {"score": 100.0, "weight": 3.0, "rule_id": 13, "rule_name": "使用权界定", "dimension_code": "O", "risk_threshold": 45.0}, {"score": 70.0, "weight": 3.0, "rule_id": 14, "rule_name": "收益权分配", "dimension_code": "O", "risk_threshold": 45.0}, {"score": 50.0, "weight": 3.0, "rule_id": 15, "rule_name": "数据独创性评估", "dimension_code": "O", "risk_threshold": 50.0}, {"score": 60.0, "weight": 4.0, "rule_id": 29, "rule_name": "数据增长趋势", "dimension_code": "P", "risk_threshold": 45.0}, {"score": 52.0, "weight": 4.0, "rule_id": 30, "rule_name": "技术创新能力", "dimension_code": "P", "risk_threshold": 45.0}, {"score": 85.0, "weight": 3.0, "rule_id": 31, "rule_name": "市场拓展空间", "dimension_code": "P", "risk_threshold": 40.0}, {"score": 90.0, "weight": 4.0, "rule_id": 8, "rule_name": "数据质量管理", "dimension_code": "Q", "risk_threshold": 50.0}, {"score": 70.0, "weight": 4.0, "rule_id": 9, "rule_name": "元数据完整性", "dimension_code": "Q", "risk_threshold": 50.0}, {"score": 90.0, "weight": 3.0, "rule_id": 10, "rule_name": "数据标准化程度", "dimension_code": "Q", "risk_threshold": 45.0}, {"score": 70.0, "weight": 3.0, "rule_id": 11, "rule_name": "数据类型多样性", "dimension_code": "Q", "risk_threshold": 45.0}, {"score": 90.0, "weight": 3.0, "rule_id": 20, "rule_name": "合规成本核算", "dimension_code": "S", "risk_threshold": 45.0}, {"score": 83.3, "weight": 4.0, "rule_id": 21, "rule_name": "存储成本计量", "dimension_code": "S", "risk_threshold": 50.0}, {"score": 70.0, "weight": 3.0, "rule_id": 22, "rule_name": "运维成本统计", "dimension_code": "S", "risk_threshold": 45.0}, {"score": 80.0, "weight": 4.0, "rule_id": 16, "rule_name": "数据应用场景", "dimension_code": "V", "risk_threshold": 45.0}, {"score": 70.0, "weight": 4.0, "rule_id": 17, "rule_name": "数据价值评估", "dimension_code": "V", "risk_threshold": 50.0}, {"score": 70.0, "weight": 3.0, "rule_id": 18, "rule_name": "数据变现能力", "dimension_code": "V", "risk_threshold": 40.0}, {"score": 30.0, "weight": 3.0, "rule_id": 19, "rule_name": "数据规模价值", "dimension_code": "V", "risk_threshold": 45.0}]}', '2026-03-14 22:50:40');

-- 表: knowledge_categories
DROP TABLE IF EXISTS `knowledge_categories`;
CREATE TABLE `knowledge_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '目录名称',
  `parent_id` int DEFAULT NULL COMMENT '父目录ID',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '目录描述',
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目录图标',
  `sort_order` int DEFAULT '0' COMMENT '排序顺序',
  `is_active` tinyint DEFAULT '1' COMMENT '是否启用',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `knowledge_categories` VALUES (5, '政策法规', NULL, '国家及地方数据要素相关政策法规', 'bi bi-bank', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(6, '国家法律', 5, '全国人大制定的数据相关法律', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(7, '行政法规', 5, '国务院发布的数据相关行政法规', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(8, '部门规章', 5, '各部委发布的数据管理规定', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(9, '地方性法规', 5, '各省市发布的数据相关法规', 'bi bi-file-text', 4, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(10, '政策文件', 5, '政府发布的指导性政策文件', 'bi bi-file-text', 5, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(11, '标准规范', NULL, '数据要素领域各类标准规范', 'bi bi-file-earmark-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(12, '国家标准', 11, 'GB系列数据相关国家标准', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(13, '行业标准', 11, '各行业数据管理标准', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(14, '地方标准', 11, '地方发布的数据标准', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(15, '团体标准', 11, '行业协会发布的数据标准', 'bi bi-file-text', 4, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(16, '数据确权', NULL, '数据权属确认与登记相关规范', 'bi bi-shield-check', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(17, '确权指南', 16, '数据权属确认操作指南', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(18, '登记规范', 16, '数据资产登记相关规范', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(19, '知识产权', 16, '数据知识产权保护相关文件', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(20, '数据估值', NULL, '数据资产评估与定价方法', 'bi bi-calculator', 4, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(21, '评估方法', 20, '数据资产评估方法论', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(22, '定价模型', 20, '数据定价模型与案例', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(23, '成本核算', 20, '数据成本归集与核算方法', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(24, '数据交易', NULL, '数据交易流通相关规范', 'bi bi-arrow-left-right', 5, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(25, '交易规则', 24, '数据交易所交易规则', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(26, '合同范本', 24, '数据交易合同模板', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(27, '流通规范', 24, '数据流通与共享规范', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(28, '数据安全', NULL, '数据安全与隐私保护', 'bi bi-lock', 6, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(29, '安全标准', 28, '数据安全相关标准', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(30, '隐私保护', 28, '隐私保护与合规指南', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(31, '安全技术', 28, '数据安全技术与工具', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(32, '数据质量', NULL, '数据质量管理相关规范', 'bi bi-check-circle', 7, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(33, '质量标准', 32, '数据质量评价标准', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(34, '治理方法', 32, '数据治理方法论', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(35, '检测工具', 32, '数据质量检测工具介绍', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(36, '会计入表', NULL, '数据资源会计入表相关规范', 'bi bi-journal-bookmark', 8, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(37, '会计准则', 36, '数据资源会计处理准则', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(38, '操作指引', 36, '数据资产入表操作指引', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(39, '审计要求', 36, '数据资产审计相关要求', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(40, '行业应用', NULL, '各行业数据要素应用案例', 'bi bi-building', 9, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(41, '金融服务', 40, '金融行业数据应用', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(42, '医疗健康', 40, '医疗健康数据应用', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(43, '交通运输', 40, '交通物流数据应用', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(44, '工业制造', 40, '工业制造数据应用', 'bi bi-file-text', 4, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(45, '农业农村', 40, '农业农村数据应用', 'bi bi-file-text', 5, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(46, '政务服务', 40, '政务数据开放共享', 'bi bi-file-text', 6, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(47, '典型案例', NULL, '数据要素典型案例分析', 'bi bi-journal-text', 10, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(48, '确权案例', 47, '数据确权典型案例', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(49, '估值案例', 47, '数据估值典型案例', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(50, '交易案例', 47, '数据交易典型案例', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(51, '入表案例', 47, '数据资产入表典型案例', 'bi bi-file-text', 4, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(52, '操作指南', NULL, '数据要素相关操作手册', 'bi bi-book', 11, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(53, '评估指南', 52, '数据资产评估操作指南', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(54, '填报指南', 52, '数据要素填报操作指南', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(55, '系统使用', 52, '系统功能使用说明', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(56, '研究报告', NULL, '数据要素领域研究报告', 'bi bi-graph-up', 12, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(57, '市场研究', 56, '数据要素市场研究报告', 'bi bi-file-text', 1, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(58, '技术发展', 56, '数据技术发展趋势报告', 'bi bi-file-text', 2, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36'),
(59, '政策解读', 56, '数据政策深度解读', 'bi bi-file-text', 3, 1, '2026-03-19 19:25:36', '2026-03-19 19:25:36');

-- 表: knowledge_docs
DROP TABLE IF EXISTS `knowledge_docs`;
CREATE TABLE `knowledge_docs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `doc_type` varchar(50) DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `content` text,
  `tags` json DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category_id` int DEFAULT NULL COMMENT '鐩綍鍒嗙被ID',
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `knowledge_docs` VALUES (1, NULL, '“数据要素×”三年行动计划 (2024—2026 年)', '“数据要素×”三年行动计划（2024—2026年）
发挥数据要素的放大、叠加、倍增作用，构建以数据为关键
要素的数字经济，是推动高质量发展的必然要求。为深入贯彻党
的二十大和中央经济工作会议精神，落实《中共中央国务院关
于构建数据基础制度更好发挥数据要素作用的意见》，充分发挥
数据要素乘数效应，赋能经济社会发展，特制定本行动计划。
一、激活数据要素潜能
随着新一轮科技革命和产业变革深入发展，数据作为关键生
产要素的价值日益凸显。发挥数据要素报酬递增、低成本复用等
特点，可优化资源配置，赋能实体经济，发展新质生产力，推动
生产生活、经济发展和社会治理方式深刻变革，对推动高质量发
展具有重要意义。
近年来，我国数字经济快速发展，数字基础设施规模能级大
幅跃升，数字技术和产业体系日臻成熟，为更好发挥数据要素作
用奠定了坚实基础。与此同时，也存在数据供给质量不高、流通
机制不畅、应用潜力释放不够等问题。实施“数据要素×”行动，
就是要发挥我国超大规模市场、海量数据资源、丰富应用场景等
多重优势，推动数据要素与劳动力、资本等要素协同，以数据流
引领技术流、资金流、人才流、物资流，突破传统资源要素约束，
提高全要素生产率；促进数据多场景应用、多主体复用，培育基
于数据要素的新产品和新服务，实现知识扩散、价值倍增，开辟

经济增长新空间；加快多元数据融合，以数据规模扩张和数据类
型丰富，促进生产工具创新升级，催生新产业、新模式，培育经
济发展新动能。
二、总体要求
（一）指导思想
以习近平新时代中国特色社会主义思想为指导，深入贯彻落
实党的二十大精神，完整、准确、全面贯彻新发展理念，发挥数
据的基础资源作用和创新引擎作用，遵循数字经济发展规律，以
推动数据要素高水平应用为主线，以推进数据要素协同优化、复
用增效、融合创新作用发挥为重点，强化场景需求牵引，带动数
据要素高质量供给、合规高效流通，培育新产业、新模式、新动
能，充分实现数据要素价值，为推动高质量发展、推进中国式现
代化提供有力支撑
（二）基本原则
需求牵引，注重实效。聚焦重点行业和领域，挖掘典型数据
要素应用场景，培育数据商，繁荣数据产业生态，激励各类主体
积极参与数据要素开发利用。
试点先行，重点突破。加强试点工作，探索多样化、可持续
的数据要素价值释放路径。推动在数据资源丰富、带动性强、前
景广阔的领域率先突破，发挥引领作用。

有效市场，有为政府。充分发挥市场机制作用，强化企业主
体地位，推动数据资源有效配置。更好发挥政府作用，扩大公共
数据资源供给，维护公平正义，营造良好发展环境。
开放融合，安全有序。推动数字经济领域高水平对外开放，
加强国际交流互鉴，促进数据有序跨境流动。坚持把安全贯穿数
据要素价值创造和实现全过程，严守数据安全底线。
（三）总体目标
到2026年底，数据要素应用广度和深度大幅拓展，在经济
发展领域数据要素乘数效应得到显现，打造300个以上示范性强、
显示度高、带动性广的典型应用场景，涌现出一批成效明显的数
据要素应用示范地区，培育一批创新能力强、成长性好的数据商
和第三方专业服务机构，形成相对完善的数据产业生态，数据产
品和服务质量效益明显提升，数据产业年均增速超过20%，场内
交易与场外交易协调发展，数据交易规模倍增，推动数据要素价
值创造的新业态成为经济增长新动力，数据赋能经济提质增效作
用更加凸显，成为高质量发展的重要驱动力量。
三、重点行动
（四）数据要素×工业制造
创新研发模式，支持工业制造类企业融合设计、仿真、实验
验证数据，培育数据驱动型产品研发新模式，提升企业创新能力。
推动协同制造，推进产品主数据标准生态系统建设，支持链主企
业打通供应链上下游设计、计划、质量、物流等数据，实现敏捷

柔性协同制造。提升服务能力，支持企业整合设计、生产、运行
数据，提升预测性维护和增值服务等能力，实现价值链延伸。强
化区域联动，支持产能、采购、库存、物流数据流通，加强区域
间制造资源协同，促进区域产业优势互补，提升产业链供应链监
测预警能力。开发使能技术，推动制造业数据多场景复用，支持
制造业企业联合软件企业，基于设计、仿真、实验、生产、运行
等数据积极探索多维度的创新应用，开发创成式设计、虚实融合
试验、智能无人装备等方面的新型工业软件和装备。
（五）数据要素×现代农业
提升农业生产数智化水平，支持农业生产经营主体和相关服
务企业融合利用遥感、气象、土壤、农事作业、灾害、农作物病
虫害、动物疫病、市场等数据，加快打造以数据和模型为支撑的
农业生产数智化场景，实现精准种植、精准养殖、精准捕捞等智
慧农业作业方式，支撑提高粮食和重要农产品生产效率。提高农
产品追溯管理能力，支持第三方主体汇聚利用农产品的产地、生
产、加工、质检等数据，支撑农产品追溯管理、精准营销等，增
强消费者信任。推进产业链数据融通创新，支持第三方主体面向
农业生产经营主体提供智慧种养、智慧捕捞、产销对接、疫病防
治、行情信息、跨区作业等服务，打通生产、销售、加工等数据，
提供一站式采购、供应链金融等服务。培育以需定产新模式，支
持农业与商贸流通数据融合分析应用，鼓励电商平台、农产品批
发市场、商超、物流企业等基于销售数据分析，向农产品生产端、

加工端、消费端反馈农产品信息，提升农产品供需匹配能力。提
升农业生产抗风险能力，支持在粮食、生猪、果蔬等领域，强化
产能、运输、加工、贸易、消费等数据融合、分析、发布、应用，
加强农业监测预警，为应对自然灾害、疫病传播、价格波动等影
响提供支撑。
（六）数据要素×商贸流通
拓展新消费，鼓励电商平台与各类商贸经营主体、相关服务
企业深度融合，依托客流、消费行为、交通状况、人文特征等市
场环境数据，打造集数据收集、分析、决策、精准推送和动态反
馈的闭环消费生态，推进直播电商、即时电商等业态创新发展，
支持各类商圈创新应用场景，培育数字生活消费方式。培育新业
态，支持电子商务企业、国家电子商务示范基地、传统商贸流通
企业加强数据融合，整合订单需求、物流、产能、供应链等数据，
优化配置产业链资源，打造快速响应市场的产业协同创新生态。
打造新品牌，支持电子商务企业、商贸企业依托订单数量、订单
类型、人口分布等数据，主动对接生产企业、产业集群，加强产
销对接、精准推送，助力打造特色品牌。推进国际化，在安全合
规前提下，鼓励电子商务企业、现代流通企业、数字贸易龙头企
业融合交易、物流、支付数据，支撑提升供应链综合服务、跨境
身份认证、全球供应链融资等能力。
（七）数据要素×交通运输

提升多式联运效能，推进货运寄递数据、运单数据、结算数
据、保险数据、货运跟踪数据等共享互认，实现托运人一次委托、
费用一次结算、货物一次保险、多式联运经营人全程负责。推进
航运贸易便利化，推动航运贸易数据与电子发票核验、经营主体
身份核验、报关报检状态数据等的可信融合应用，加快推广电子
提单、信用证、电子放货等业务应用。提升航运服务能力，支持
海洋地理空间、卫星遥感、定位导航、气象等数据与船舶航行位
置、水域、航速、装卸作业数据融合，创新商渔船防碰撞、航运
路线规划、港口智慧安检等应用。挖掘数据复用价值，融合“两
客一危”、网络货运等重点车辆数据，构建覆盖车辆营运行为、
事故统计等高质量动态数据集，为差异化信贷、保险服务、二手
车消费等提供数据支撑。支持交通运输龙头企业推进高质量数据
集建设和复用，加强人工智能工具应用，助力企业提升运输效率。
推进智能网联汽车创新发展，支持自动驾驶汽车在特定区域、特
定时段进行商业化试运营试点，打通车企、第三方平台、运输企
业等主体间的数据壁垒，促进道路基础设施数据、交通流量数据、
驾驶行为数据等多源数据融合应用，提高智能汽车创新服务、主
动安全防控等水平。
（八）数据要素×金融服务
提升金融服务水平，支持金融机构融合利用科技、环保、工
商、税务、气象、消费、医疗、社保、农业农村、水电气等数据，
加强主体识别，依法合规优化信贷业务管理和保险产品设计及承

保理赔服务，提升实体经济金融服务水平。提高金融抗风险能力，
推进数字金融发展，在依法安全合规前提下，推动金融信用数据
和公共信用数据、商业信用数据共享共用和高效流通，支持金融
机构间共享风控类数据，融合分析金融市场、信贷资产、风险核
查等多维数据，发挥金融科技和数据要素的驱动作用，支撑提升
金融机构反欺诈、反洗钱能力，提高风险预警和防范水平。
（九）数据要素×科技创新
推动科学数据有序开放共享，促进重大科技基础设施、科技
重大项目等产生的各类科学数据互联互通，支持和培育具有国际
影响力的科学数据库建设，依托国家科学数据中心等平台强化高
质量科学数据资源建设和场景应用。以科学数据助力前沿研究，
面向基础学科，提供高质量科学数据资源与知识服务，驱动科学
创新发现。以科学数据支撑技术创新，聚焦生物育种、新材料创
制、药物研发等领域，以数智融合加速技术创新和产业升级。以
科学数据支持大模型开发，深入挖掘各类科学数据和科技文献，
通过细粒度知识抽取和多来源知识融合，构建科学知识资源底座，
建设高质量语料库和基础科学数据集，支持开展人工智能大模型
开发和训练。探索科研新范式，充分依托各类数据库与知识库，
推进跨学科、跨领域协同创新，以数据驱动发现新规律，创造新
知识，加速科学研究范式变革。
（十）数据要素×文化旅游

培育文化创意新产品，推动文物、古籍、美术、戏曲剧种、
非物质文化遗产、民族民间文艺等数据资源依法开放共享和交易
流通，支持文化创意、旅游、展览等领域的经营主体加强数据开
发利用，培育具有中国文化特色的产品和品牌。挖掘文化数据价
值，贯通各类文化机构数据中心，关联形成中华文化数据库，鼓
励依托市场化机制开发文化大模型。提升文物保护利用水平，促
进文物病害数据、保护修复数据、安全监管数据、文物流通数据
融合共享，支持实现文物保护修复、监测预警、精准管理、应急
处置、阐释传播等功能。提升旅游服务水平，支持旅游经营主体
共享气象、交通等数据，在合法合规前提下构建客群画像、城市
画像等，优化旅游配套服务、一站式出行服务。提升旅游治理能
力，支持文化和旅游场所共享公安、交通、气象、证照等数据，
支撑“免证”购票、集聚人群监测预警、应急救援等。
（十一）数据要素×医疗健康
提升群众就医便捷度，探索推进电子病历数据共享，在医疗
机构间推广检查检验结果数据标准统一和共享互认。便捷医疗理
赔结算，支持医疗机构基于信用数据开展先诊疗后付费就医。推
动医保便民服务。依法依规探索推进医保与商业健康保险数据融
合应用，提升保险服务水平，促进基本医保与商业健康保险协同
发展。有序释放健康医疗数据价值，完善个人健康数据档案，融
合体检、就诊、疾控等数据，创新基于数据驱动的职业病监测、
公共卫生事件预警等公共服务模式。加强医疗数据融合创新，支

持公立医疗机构在合法合规前提下向金融、养老等经营主体共享
数据，支撑商业保险产品、疗养休养等服务产品精准设计，拓展
智慧医疗、智能健康管理等数据应用新模式新业态。提升中医药
发展水平，加强中医药预防、治疗、康复等健康服务全流程的多
源数据融合，支撑开展中医药疗效、药物相互作用、适应症、安
全性等系统分析，推进中医药高质量发展。
（十二）数据要素×应急管理
提升安全生产监管能力，探索利用电力、通信、遥感、消防
等数据，实现对高危行业企业私挖盗采、明停暗开行为的精准监
管和城市火灾的智能监测。鼓励社会保险企业围绕矿山、危险化
学品等高危行业，研究建立安全生产责任保险评估模型，开发新
险种，提高风险评估的精准性和科学性。提升自然灾害监测评估
能力，利用铁塔、电力、气象等公共数据，研发自然灾害灾情监
测评估模型，强化灾害风险精准预警研判能力。强化地震活动、
地壳形变、地下流体等监测数据的融合分析，提升地震预测预警
水平。提升应急协调共享能力，推动灾害事故、物资装备、特种
作业人员、安全生产经营许可等数据跨区域共享共用，提高监管
执法和救援处置协同联动效率。
（十三）数据要素×气象服务
降低极端天气气候事件影响，支持经济社会、生态环境、自
然资源、农业农村等数据与气象数据融合应用，实现集气候变化
风险识别、风险评估、风险预警、风险转移的智能决策新模式，

防范化解重点行业和产业气候风险。支持气象数据与城市规划、
重大工程等建设数据深度融合，从源头防范和减轻极端天气和不
利气象条件对规划和工程的影响。创新气象数据产品服务，支持
金融企业融合应用气象数据，发展天气指数保险、天气衍生品和
气候投融资新产品，为保险、期货等提供支撑。支持新能源企业
降本增效，支持风能、太阳能企业融合应用气象数据，优化选址
布局、设备运维、能源调度等。
（十四）数据要素×城市治理
优化城市管理方式，推动城市人、地、事、物、情、组织等
多维度数据融通，支撑公共卫生、交通管理、公共安全、生态环
境、基层治理、体育赛事等各领域场景应用，实现态势实时感知、
风险智能研判、及时协同处置。支撑城市发展科学决策，支持利
用城市时空基础、资源调查、规划管控、工程建设项目、物联网
感知等数据，助力城市规划、建设、管理、服务等策略精细化、
智能化。推进公共服务普惠化，深化公共数据的共享应用，深入
推动就业、社保、健康、卫生、医疗、救助、养老、助残、托育
等服务“指尖办”“网上办”“就近办”。加强区域协同治理，
推动城市群数据打通和业务协同，实现经营主体注册登记、异地
就医结算、养老保险互转等服务事项跨城通办。
（十五）数据要素×绿色低碳
提升生态环境治理精细化水平，推进气象、水利、交通、电
力等数据融合应用，支撑气象和水文耦合预报、受灾分析、河湖

岸线监测、突发水事件应急处置、重污染天气应对、城市水环境
精细化管理等。加强生态环境公共数据融合创新，支持企业融合
应用自有数据、生态环境公共数据等，优化环境风险评估，支撑
环境污染责任保险设计和绿色信贷服务。提升能源利用效率，促
进制造与能源数据融合创新，推动能源企业与高耗能企业打通订
单、排产、用电等数据，支持能耗预测、多能互补、梯度定价等
应用。提升废弃资源利用效率，汇聚固体废物收集、转移、利用、
处置等各环节数据，促进产废、运输、资源化利用高效衔接，推
动固废、危废资源化利用。提升碳排放管理水平，支持打通关键
产品全生产周期的物料、辅料、能源等碳排放数据以及行业碳足
迹数据，开展产品碳足迹测算与评价，引导企业节能降碳。
四、强化保障支撑
（十六）提升数据供给水平
完善数据资源体系，在科研、文化、交通运输等领域，推动
科研机构、龙头企业等开展行业共性数据资源库建设，打造高质
量人工智能大模型训练数据集。加大公共数据资源供给，在重点
领域、相关区域组织开展公共数据授权运营，探索部省协同的公
共数据授权机制。引导企业开放数据，鼓励市场力量挖掘商业数
据价值，支持社会数据融合创新应用。健全标准体系，加强数据
采集、管理等标准建设，协同推进行业标准制定。加强供给激励，
制定完善数据内容采集、加工、流通、应用等不同环节相关主体
的权益保护规则，在保护个人隐私前提下促进个人信息合理利用。

（十七）优化数据流通环境
提高交易流通效率，支持行业内企业联合制定数据流通规则、
标准，聚焦业务需求促进数据合规流通，提高多主体间数据应用
效率。鼓励交易场所强化合规管理，创新服务模式，打造服务生
态，提升服务质量。打造安全可信流通环境，深化数据空间、隐
私计算、联邦学习、区块链、数据沙箱等技术应用，探索建设重
点行业和领域数据流通平台，增强数据利用可信、可控、可计量
能力，促进数据合规高效流通使用。培育流通服务主体，鼓励地
方政府因地制宜，通过新建或拓展既有园区功能等方式，建设数
据特色园区、虚拟园区，推动数据商、第三方专业服务机构等协
同发展。完善培育数据商的支持举措。促进数据有序跨境流动，
对标国际高标准经贸规则，持续优化数据跨境流动监管措施，支
持自由贸易试验区开展探索。
（十八）加强数据安全保障
落实数据安全法规制度，完善数据分类分级保护制度，落实
网络安全等级保护、关键信息基础设施安全保护等制度，加强个
人信息保护，提升数据安全保障水平。丰富数据安全产品，发展
面向重点行业、重点领域的精细化、专业型数据安全产品，开发
适合中小企业的解决方案和工具包，支持发展定制化、轻便化的
个人数据安全防护产品。培育数据安全服务，鼓励数据安全企业
开展基于云端的安全服务，有效提升数据安全水平。
五、做好组织实施

（十九）加强组织领导
发挥数字经济发展部际联席会议制度作用，强化重点工作跟
踪和任务落实，协调推进跨部门协作。行业主管部门要聚焦重点
行业数据开发利用需求，细化落实行动计划的举措。地方数据管
理部门要会同相关部门研究制定落实方案，因地制宜形成符合实
际的数据要素应用实践，带动培育一批数据商和第三方专业服务
机构，营造良好生态。
（二十）开展试点工作
支持部门、地方协同开展政策性试点，聚焦重点行业和领域，
结合场景需求，研究数据资源持有权、数据加工使用权、数据产
品经营权等分置的落地举措，探索数据流通交易模式。鼓励各地
方大胆探索、先行先试，加强模式创新，及时总结可复制推广的
实践经验。推动企业按照国家统一的会计制度对数据资源进行会
计处理。
（二十一）推动以赛促用
组织开展“数据要素×”大赛，聚焦重点行业和领域搭建专
业竞赛平台，加强数据资源供给，激励社会各界共同挖掘市场需
求，提升数据利用水平。支持各类企业参与赛事，加强大赛成果
转化，孵化新技术、新产品，培育新模式、新业态，完善数据要
素生态。
（二十二）加强资金支持

实施“数据要素×”试点工程，统筹利用中央预算内投资和
其他各类资金加大支持力度。鼓励金融机构按照市场化原则加大
信贷支持力度，优化金融服务。依法合规探索多元化投融资模式，
发挥相关引导基金、产业基金作用，引导和鼓励各类社会资本投
向数据产业。支持数据商上市融资。
（二十三）加强宣传推广
开展数据要素应用典型案例评选，遴选一批典型应用。依托
数字中国建设峰会及各类数据要素相关会议、论坛和活动等，积
极发布典型案例，促进经验分享和交流合作。各地方数据管理部
门要深入挖掘数据要素应用好经验、好做法，充分利用各类新闻
媒体，加大宣传力度，提升影响力。', NULL, NULL, 1, NULL, '2026-03-21 17:05:44', 10, 1),
(2, NULL, '《关于构建数据基础制度更好发挥数据要素作用的意见》(简称“数据二十条”)', '窗体顶端

窗体底端

首页 > 国务院公报 > 2023年第1号

中共中央 国务院关于构建数据基础制度

更好发挥数据要素作用的意见

（2022年12月2日）

数据作为新型生产要素，是数字化、网络化、智能化的基础，已快速融入生产、分配、流通、消费和社会服务管理等各环节，深刻改变着生产方式、生活方式和社会治理方式。数据基础制度建设事关国家发展和安全大局。为加快构建数据基础制度，充分发挥我国海量数据规模和丰富应用场景优势，激活数据要素潜能，做强做优做大数字经济，增强经济发展新动能，构筑国家竞争新优势，现提出如下意见。

一、总体要求

（一）指导思想。以习近平新时代中国特色社会主义思想为指导，深入贯彻党的二十大精神，完整、准确、全面贯彻新发展理念，加快构建新发展格局，坚持改革创新、系统谋划，以维护国家数据安全、保护个人信息和商业秘密为前提，以促进数据合规高效流通使用、赋能实体经济为主线，以数据产权、流通交易、收益分配、安全治理为重点，深入参与国际高标准数字规则制定，构建适应数据特征、符合数字经济发展规律、保障国家数据安全、彰显创新引领的数据基础制度，充分实现数据要素价值、促进全体人民共享数字经济发展红利，为深化创新驱动、推动高质量发展、推进国家治理体系和治理能力现代化提供有力支撑。

（二）工作原则

——遵循发展规律，创新制度安排。充分认识和把握数据产权、流通、交易、使用、分配、治理、安全等基本规律，探索有利于数据安全保护、有效利用、合规流通的产权制度和市场体系，完善数据要素市场体制机制，在实践中完善，在探索中发展，促进形成与数字生产力相适应的新型生产关系。

——坚持共享共用，释放价值红利。合理降低市场主体获取数据的门槛，增强数据要素共享性、普惠性，激励创新创业创造，强化反垄断和反不正当竞争，形成依法规范、共同参与、各取所需、共享红利的发展模式。

——强化优质供给，促进合规流通。顺应经济社会数字化转型发展趋势，推动数据要素供给调整优化，提高数据要素供给数量和质量。建立数据可信流通体系，增强数据的可用、可信、可流通、可追溯水平。实现数据流通全过程动态管理，在合规流通使用中激活数据价值。

——完善治理体系，保障安全发展。统筹发展和安全，贯彻总体国家安全观，强化数据安全保障体系建设，把安全贯穿数据供给、流通、使用全过程，划定监管底线和红线。加强数据分类分级管理，把该管的管住、该放的放开，积极有效防范和化解各种数据风险，形成政府监管与市场自律、法治与行业自治协同、国内与国际统筹的数据要素治理结构。

——深化开放合作，实现互利共赢。积极参与数据跨境流动国际规则制定，探索加入区域性国际数据跨境流动制度安排。推动数据跨境流动双边多边协商，推进建立互利互惠的规则等制度安排。鼓励探索数据跨境流动与合作的新途径新模式。

二、建立保障权益、合规使用的数据产权制度

探索建立数据产权制度，推动数据产权结构性分置和有序流通，结合数据要素特性强化高质量数据要素供给；在国家数据分类分级保护制度下，推进数据分类分级确权授权使用和市场化流通交易，健全数据要素权益保护制度，逐步形成具有中国特色的数据产权制度体系。

（三）探索数据产权结构性分置制度。建立公共数据、企业数据、个人数据的分类分级确权授权制度。根据数据来源和数据生成特征，分别界定数据生产、流通、使用过程中各参与方享有的合法权利，建立数据资源持有权、数据加工使用权、数据产品经营权等分置的产权运行机制，推进非公共数据按市场化方式“共同使用、共享收益”的新模式，为激活数据要素价值创造和价值实现提供基础性制度保障。研究数据产权登记新方式。在保障安全前提下，推动数据处理者依法依规对原始数据进行开发利用，支持数据处理者依法依规行使数据应用相关权利，促进数据使用价值复用与充分利用，促进数据使用权交换和市场化流通。审慎对待原始数据的流转交易行为。

（四）推进实施公共数据确权授权机制。对各级党政机关、企事业单位依法履职或提供公共服务过程中产生的公共数据，加强汇聚共享和开放开发，强化统筹授权使用和管理，推进互联互通，打破“数据孤岛”。鼓励公共数据在保护个人隐私和确保公共安全的前提下，按照“原始数据不出域、数据可用不可见”的要求，以模型、核验等产品和服务等形式向社会提供，对不承载个人信息和不影响公共安全的公共数据，推动按用途加大供给使用范围。推动用于公共治理、公益事业的公共数据有条件无偿使用，探索用于产业发展、行业发展的公共数据有条件有偿使用。依法依规予以保密的公共数据不予开放，严格管控未依法依规公开的原始公共数据直接进入市场，保障公共数据供给使用的公共利益。

（五）推动建立企业数据确权授权机制。对各类市场主体在生产经营活动中采集加工的不涉及个人信息和公共利益的数据，市场主体享有依法依规持有、使用、获取收益的权益，保障其投入的劳动和其他要素贡献获得合理回报，加强数据要素供给激励。鼓励探索企业数据授权使用新模式，发挥国有企业带头作用，引导行业龙头企业、互联网平台企业发挥带动作用，促进与中小微企业双向公平授权，共同合理使用数据，赋能中小微企业数字化转型。支持第三方机构、中介服务组织加强数据采集和质量评估标准制定，推动数据产品标准化，发展数据分析、数据服务等产业。政府部门履职可依法依规获取相关企业和机构数据，但须约定并严格遵守使用限制要求。

（六）建立健全个人信息数据确权授权机制。对承载个人信息的数据，推动数据处理者按照个人授权范围依法依规采集、持有、托管和使用数据，规范对个人信息的处理活动，不得采取“一揽子授权”、强制同意等方式过度收集个人信息，促进个人信息合理利用。探索由受托者代表个人利益，监督市场主体对个人信息数据进行采集、加工、使用的机制。对涉及国家安全的特殊个人信息数据，可依法依规授权有关单位使用。加大个人信息保护力度，推动重点行业建立完善长效保护机制，强化企业主体责任，规范企业采集使用个人信息行为。创新技术手段，推动个人信息匿名化处理，保障使用个人信息数据时的信息安全和个人隐私。

（七）建立健全数据要素各参与方合法权益保护制度。充分保护数据来源者合法权益，推动基于知情同意或存在法定事由的数据流通使用模式，保障数据来源者享有获取或复制转移由其促成产生数据的权益。合理保护数据处理者对依法依规持有的数据进行自主管控的权益。在保护公共利益、数据安全、数据来源者合法权益的前提下，承认和保护依照法律规定或合同约定获取的数据加工使用权，尊重数据采集、加工等数据处理者的劳动和其他要素贡献，充分保障数据处理者使用数据和获得收益的权利。保护经加工、分析等形成数据或数据衍生产品的经营权，依法依规规范数据处理者许可他人使用数据或数据衍生产品的权利，促进数据要素流通复用。建立健全基于法律规定或合同约定流转数据相关财产性权益的机制。在数据处理者发生合并、分立、解散、被宣告破产时，推动相关权利和义务依法依规同步转移。

三、建立合规高效、场内外结合的数据要素流通和交易制度

完善和规范数据流通规则，构建促进使用和流通、场内场外相结合的交易制度体系，规范引导场外交易，培育壮大场内交易；有序发展数据跨境流通和交易，建立数据来源可确认、使用范围可界定、流通过程可追溯、安全风险可防范的数据可信流通体系。

（八）完善数据全流程合规与监管规则体系。建立数据流通准入标准规则，强化市场主体数据全流程合规治理，确保流通数据来源合法、隐私保护到位、流通和交易规范。结合数据流通范围、影响程度、潜在风险，区分使用场景和用途用量，建立数据分类分级授权使用规范，探索开展数据质量标准化体系建设，加快推进数据采集和接口标准化，促进数据整合互通和互操作。支持数据处理者依法依规在场内和场外采取开放、共享、交换、交易等方式流通数据。鼓励探索数据流通安全保障技术、标准、方案。支持探索多样化、符合数据要素特性的定价模式和价格形成机制，推动用于数字化发展的公共数据按政府指导定价有偿使用，企业与个人信息数据市场自主定价。加强企业数据合规体系建设和监管，严厉打击黑市交易，取缔数据流通非法产业。建立实施数据安全管理认证制度，引导企业通过认证提升数据安全管理水平。

（九）统筹构建规范高效的数据交易场所。加强数据交易场所体系设计，统筹优化数据交易场所的规划布局，严控交易场所数量。出台数据交易场所管理办法，建立健全数据交易规则，制定全国统一的数据交易、安全等标准体系，降低交易成本。引导多种类型的数据交易场所共同发展，突出国家级数据交易场所合规监管和基础服务功能，强化其公共属性和公益定位，推进数据交易场所与数据商功能分离，鼓励各类数据商进场交易。规范各地区各部门设立的区域性数据交易场所和行业性数据交易平台，构建多层次市场交易体系，推动区域性、行业性数据流通使用。促进区域性数据交易场所和行业性数据交易平台与国家级数据交易场所互联互通。构建集约高效的数据流通基础设施，为场内集中交易和场外分散交易提供低成本、高效率、可信赖的流通环境。

（十）培育数据要素流通和交易服务生态。围绕促进数据要素合规高效、安全有序流通和交易需要，培育一批数据商和第三方专业服务机构。通过数据商，为数据交易双方提供数据产品开发、发布、承销和数据资产的合规化、标准化、增值化服务，促进提高数据交易效率。在智能制造、节能降碳、绿色建造、新能源、智慧城市等重点领域，大力培育贴近业务需求的行业性、产业化数据商，鼓励多种所有制数据商共同发展、平等竞争。有序培育数据集成、数据经纪、合规认证、安全审计、数据公证、数据保险、数据托管、资产评估、争议仲裁、风险评估、人才培训等第三方专业服务机构，提升数据流通和交易全流程服务能力。

（十一）构建数据安全合规有序跨境流通机制。开展数据交互、业务互通、监管互认、服务共享等方面国际交流合作，推进跨境数字贸易基础设施建设，以《全球数据安全倡议》为基础，积极参与数据流动、数据安全、认证评估、数字货币等国际规则和数字技术标准制定。坚持开放发展，推动数据跨境双向有序流动，鼓励国内外企业及组织依法依规开展数据跨境流动业务合作，支持外资依法依规进入开放领域，推动形成公平竞争的国际化市场。针对跨境电商、跨境支付、供应链管理、服务外包等典型应用场景，探索安全规范的数据跨境流动方式。统筹数据开发利用和数据安全保护，探索建立跨境数据分类分级管理机制。对影响或者可能影响国家安全的数据处理、数据跨境传输、外资并购等活动依法依规进行国家安全审查。按照对等原则，对维护国家安全和利益、履行国际义务相关的属于管制物项的数据依法依规实施出口管制，保障数据用于合法用途，防范数据出境安全风险。探索构建多渠道、便利化的数据跨境流动监管机制，健全多部门协调配合的数据跨境流动监管体系。反对数据霸权和数据保护主义，有效应对数据领域“长臂管辖”。

四、建立体现效率、促进公平的数据要素收益分配制度

顺应数字产业化、产业数字化发展趋势，充分发挥市场在资源配置中的决定性作用，更好发挥政府作用。完善数据要素市场化配置机制，扩大数据要素市场化配置范围和按价值贡献参与分配渠道。完善数据要素收益的再分配调节机制，让全体人民更好共享数字经济发展成果。

（十二）健全数据要素由市场评价贡献、按贡献决定报酬机制。结合数据要素特征，优化分配结构，构建公平、高效、激励与规范相结合的数据价值分配机制。坚持“两个毫不动摇”，按照“谁投入、谁贡献、谁受益”原则，着重保护数据要素各参与方的投入产出收益，依法依规维护数据资源资产权益，探索个人、企业、公共数据分享价值收益的方式，建立健全更加合理的市场评价机制，促进劳动者贡献和劳动报酬相匹配。推动数据要素收益向数据价值和使用价值的创造者合理倾斜，确保在开发挖掘数据价值各环节的投入有相应回报，强化基于数据价值创造和价值实现的激励导向。通过分红、提成等多种收益共享方式，平衡兼顾数据内容采集、加工、流通、应用等不同环节相关主体之间的利益分配。

（十三）更好发挥政府在数据要素收益分配中的引导调节作用。逐步建立保障公平的数据要素收益分配体制机制，更加关注公共利益和相对弱势群体。加大政府引导调节力度，探索建立公共数据资源开放收益合理分享机制，允许并鼓励各类企业依法依规依托公共数据提供公益服务。推动大型数据企业积极承担社会责任，强化对弱势群体的保障帮扶，有力有效应对数字化转型过程中的各类风险挑战。不断健全数据要素市场体系和制度规则，防止和依法依规规制资本在数据领域无序扩张形成市场垄断等问题。统筹使用多渠道资金资源，开展数据知识普及和教育培训，提高社会整体数字素养，着力消除不同区域间、人群间数字鸿沟，增进社会公平、保障民生福祉、促进共同富裕。

五、建立安全可控、弹性包容的数据要素治理制度

把安全贯穿数据治理全过程，构建政府、企业、社会多方协同的治理模式，创新政府治理方式，明确各方主体责任和义务，完善行业自律机制，规范市场发展秩序，形成有效市场和有为政府相结合的数据要素治理格局。

（十四）创新政府数据治理机制。充分发挥政府有序引导和规范发展的作用，守住安全底线，明确监管红线，打造安全可信、包容创新、公平开放、监管有效的数据要素市场环境。强化分行业监管和跨行业协同监管，建立数据联管联治机制，建立健全鼓励创新、包容创新的容错纠错机制。建立数据要素生产流通使用全过程的合规公证、安全审查、算法审查、监测预警等制度，指导各方履行数据要素流通安全责任和义务。建立健全数据流通监管制度，制定数据流通和交易负面清单，明确不能交易或严格限制交易的数据项。强化反垄断和反不正当竞争，加强重点领域执法司法，依法依规加强经营者集中审查，依法依规查处垄断协议、滥用市场支配地位和违法实施经营者集中行为，营造公平竞争、规范有序的市场环境。在落实网络安全等级保护制度的基础上全面加强数据安全保护工作，健全网络和数据安全保护体系，提升纵深防护与综合防御能力。

（十五）压实企业的数据治理责任。坚持“宽进严管”原则，牢固树立企业的责任意识和自律意识。鼓励企业积极参与数据要素市场建设，围绕数据来源、数据产权、数据质量、数据使用等，推行面向数据商及第三方专业服务机构的数据流通交易声明和承诺制。严格落实相关法律规定，在数据采集汇聚、加工处理、流通交易、共享利用等各环节，推动企业依法依规承担相应责任。企业应严格遵守反垄断法等相关法律规定，不得利用数据、算法等优势和技术手段排除、限制竞争，实施不正当竞争。规范企业参与政府信息化建设中的政务数据安全管理，确保有规可循、有序发展、安全可控。建立健全数据要素登记及披露机制，增强企业社会责任，打破“数据垄断”，促进公平竞争。

（十六）充分发挥社会力量多方参与的协同治理作用。鼓励行业协会等社会力量积极参与数据要素市场建设，支持开展数据流通相关安全技术研发和服务，促进不同场景下数据要素安全可信流通。建立数据要素市场信用体系，逐步完善数据交易失信行为认定、守信激励、失信惩戒、信用修复、异议处理等机制。畅通举报投诉和争议仲裁渠道，维护数据要素市场良好秩序。加快推进数据管理能力成熟度国家标准及数据要素管理规范贯彻执行工作，推动各部门各行业完善元数据管理、数据脱敏、数据质量、价值评估等标准体系。

六、保障措施

加大统筹推进力度，强化任务落实，创新政策支持，鼓励有条件的地方和行业在制度建设、技术路径、发展模式等方面先行先试，鼓励企业创新内部数据合规管理体系，不断探索完善数据基础制度。

（十七）切实加强组织领导。加强党对构建数据基础制度工作的全面领导，在党中央集中统一领导下，充分发挥数字经济发展部际联席会议作用，加强整体工作统筹，促进跨地区跨部门跨层级协同联动，强化督促指导。各地区各部门要高度重视数据基础制度建设，统一思想认识，加大改革力度，结合各自实际，制定工作举措，细化任务分工，抓好推进落实。

（十八）加大政策支持力度。加快发展数据要素市场，做大做强数据要素型企业。提升金融服务水平，引导创业投资企业加大对数据要素型企业的投入力度，鼓励征信机构提供基于企业运营数据等多种数据要素的多样化征信服务，支持实体经济企业特别是中小微企业数字化转型赋能开展信用融资。探索数据资产入表新模式。

（十九）积极鼓励试验探索。坚持顶层设计与基层探索结合，支持浙江等地区和有条件的行业、企业先行先试，发挥好自由贸易港、自由贸易试验区等高水平开放平台作用，引导企业和科研机构推动数据要素相关技术和产业应用创新。采用“揭榜挂帅”方式，支持有条件的部门、行业加快突破数据可信流通、安全治理等关键技术，建立创新容错机制，探索完善数据要素产权、定价、流通、交易、使用、分配、治理、安全的政策标准和体制机制，更好发挥数据要素的积极作用。

（二十）稳步推进制度建设。围绕构建数据基础制度，逐步完善数据产权界定、数据流通和交易、数据要素收益分配、公共数据授权使用、数据交易场所建设、数据治理等主要领域关键环节的政策及标准。加强数据产权保护、数据要素市场制度建设、数据要素价格形成机制、数据要素收益分配、数据跨境传输、争议解决等理论研究和立法研究，推动完善相关法律制度。及时总结提炼可复制可推广的经验和做法，以点带面推动数据基础制度构建实现新突破。数字经济发展部际联席会议定期对数据基础制度建设情况进行评估，适时进行动态调整，推动数据基础制度不断丰富完善。

（新华社北京2022年12月19日电）

', NULL, '《关于构建数据基础制度更好发挥数据要素作用的意见》(简称“数据二十条”).docx', 1, NULL, '2026-03-21 16:48:15', 10, 2),
(3, NULL, '数字中国建设整体布局规划', '窗体顶端

窗体底端

首页

中共中央 国务院印发《数字中国建设整体布局规划》

2023-02-27 18:43 来源： 新华社

字号：默认 大 超大|打印|

新华社北京2月27日电 近日，中共中央、国务院印发了《数字中国建设整体布局规划》（以下简称《规划》），并发出通知，要求各地区各部门结合实际认真贯彻落实。

《规划》指出，建设数字中国是数字时代推进中国式现代化的重要引擎，是构筑国家竞争新优势的有力支撑。加快数字中国建设，对全面建设社会主义现代化国家、全面推进中华民族伟大复兴具有重要意义和深远影响。

《规划》强调，要坚持以习近平新时代中国特色社会主义思想特别是习近平总书记关于网络强国的重要思想为指导，深入贯彻党的二十大精神，坚持稳中求进工作总基调，完整、准确、全面贯彻新发展理念，加快构建新发展格局，着力推动高质量发展，统筹发展和安全，强化系统观念和底线思维，加强整体布局，按照夯实基础、赋能全局、强化能力、优化环境的战略路径，全面提升数字中国建设的整体性、系统性、协同性，促进数字经济和实体经济深度融合，以数字化驱动生产生活和治理方式变革，为以中国式现代化全面推进中华民族伟大复兴注入强大动力。

《规划》提出，到2025年，基本形成横向打通、纵向贯通、协调有力的一体化推进格局，数字中国建设取得重要进展。数字基础设施高效联通，数据资源规模和质量加快提升，数据要素价值有效释放，数字经济发展质量效益大幅增强，政务数字化智能化水平明显提升，数字文化建设跃上新台阶，数字社会精准化普惠化便捷化取得显著成效，数字生态文明建设取得积极进展，数字技术创新实现重大突破，应用创新全球领先，数字安全保障能力全面提升，数字治理体系更加完善，数字领域国际合作打开新局面。到2035年，数字化发展水平进入世界前列，数字中国建设取得重大成就。数字中国建设体系化布局更加科学完备，经济、政治、文化、社会、生态文明建设各领域数字化发展更加协调充分，有力支撑全面建设社会主义现代化国家。

《规划》明确，数字中国建设按照“2522”的整体框架进行布局，即夯实数字基础设施和数据资源体系“两大基础”，推进数字技术与经济、政治、文化、社会、生态文明建设“五位一体”深度融合，强化数字技术创新体系和数字安全屏障“两大能力”，优化数字化发展国内国际“两个环境”。

《规划》指出，要夯实数字中国建设基础。一是打通数字基础设施大动脉。加快5G网络与千兆光网协同建设，深入推进IPv6规模部署和应用，推进移动物联网全面发展，大力推进北斗规模应用。系统优化算力基础设施布局，促进东西部算力高效互补和协同联动，引导通用数据中心、超算中心、智能计算中心、边缘数据中心等合理梯次布局。整体提升应用基础设施水平，加强传统基础设施数字化、智能化改造。二是畅通数据资源大循环。构建国家数据管理体制机制，健全各级数据统筹管理机构。推动公共数据汇聚利用，建设公共卫生、科技、教育等重要领域国家数据资源库。释放商业数据价值潜能，加快建立数据产权制度，开展数据资产计价研究，建立数据要素按价值贡献参与分配机制。

《规划》指出，要全面赋能经济社会发展。一是做强做优做大数字经济。培育壮大数字经济核心产业，研究制定推动数字产业高质量发展的措施，打造具有国际竞争力的数字产业集群。推动数字技术和实体经济深度融合，在农业、工业、金融、教育、医疗、交通、能源等重点领域，加快数字技术创新应用。支持数字企业发展壮大，健全大中小企业融通创新工作机制，发挥“绿灯”投资案例引导作用，推动平台企业规范健康发展。二是发展高效协同的数字政务。加快制度规则创新，完善与数字政务建设相适应的规章制度。强化数字化能力建设，促进信息系统网络互联互通、数据按需共享、业务高效协同。提升数字化服务水平，加快推进“一件事一次办”，推进线上线下融合，加强和规范政务移动互联网应用程序管理。三是打造自信繁荣的数字文化。大力发展网络文化，加强优质网络文化产品供给，引导各类平台和广大网民创作生产积极健康、向上向善的网络文化产品。推进文化数字化发展，深入实施国家文化数字化战略，建设国家文化大数据体系，形成中华文化数据库。提升数字文化服务能力，打造若干综合性数字文化展示平台，加快发展新型文化企业、文化业态、文化消费模式。四是构建普惠便捷的数字社会。促进数字公共服务普惠化，大力实施国家教育数字化战略行动，完善国家智慧教育平台，发展数字健康，规范互联网诊疗和互联网医院发展。推进数字社会治理精准化，深入实施数字乡村发展行动，以数字化赋能乡村产业发展、乡村建设和乡村治理。普及数字生活智能化，打造智慧便民生活圈、新型数字消费业态、面向未来的智能化沉浸式服务体验。五是建设绿色智慧的数字生态文明。推动生态环境智慧治理，加快构建智慧高效的生态环境信息化体系，运用数字技术推动山水林田湖草沙一体化保护和系统治理，完善自然资源三维立体“一张图”和国土空间基础信息平台，构建以数字孪生流域为核心的智慧水利体系。加快数字化绿色化协同转型。倡导绿色智慧生活方式。

《规划》指出，要强化数字中国关键能力。一是构筑自立自强的数字技术创新体系。健全社会主义市场经济条件下关键核心技术攻关新型举国体制，加强企业主导的产学研深度融合。强化企业科技创新主体地位，发挥科技型骨干企业引领支撑作用。加强知识产权保护，健全知识产权转化收益分配机制。二是筑牢可信可控的数字安全屏障。切实维护网络安全，完善网络安全法律法规和政策体系。增强数据安全保障能力，建立数据分类分级保护基础制度，健全网络数据监测预警和应急处置工作体系。

《规划》指出，要优化数字化发展环境。一是建设公平规范的数字治理生态。完善法律法规体系，加强立法统筹协调，研究制定数字领域立法规划，及时按程序调整不适应数字化发展的法律制度。构建技术标准体系，编制数字化标准工作指南，加快制定修订各行业数字化转型、产业交叉融合发展等应用标准。提升治理水平，健全网络综合治理体系，提升全方位多维度综合治理能力，构建科学、高效、有序的管网治网格局。净化网络空间，深入开展网络生态治理工作，推进“清朗”、“净网”系列专项行动，创新推进网络文明建设。二是构建开放共赢的数字领域国际合作格局。统筹谋划数字领域国际合作，建立多层面协同、多平台支撑、多主体参与的数字领域国际交流合作体系，高质量共建“数字丝绸之路”，积极发展“丝路电商”。拓展数字领域国际合作空间，积极参与联合国、世界贸易组织、二十国集团、亚太经合组织、金砖国家、上合组织等多边框架下的数字领域合作平台，高质量搭建数字领域开放合作新平台，积极参与数据跨境流动等相关国际规则构建。

《规划》强调，要加强整体谋划、统筹推进，把各项任务落到实处。一是加强组织领导。坚持和加强党对数字中国建设的全面领导，在党中央集中统一领导下，中央网络安全和信息化委员会加强对数字中国建设的统筹协调、整体推进、督促落实。充分发挥地方党委网络安全和信息化委员会作用，健全议事协调机制，将数字化发展摆在本地区工作重要位置，切实落实责任。各有关部门按照职责分工，完善政策措施，强化资源整合和力量协同，形成工作合力。二是健全体制机制。建立健全数字中国建设统筹协调机制，及时研究解决数字化发展重大问题，推动跨部门协同和上下联动，抓好重大任务和重大工程的督促落实。开展数字中国发展监测评估。将数字中国建设工作情况作为对有关党政领导干部考核评价的参考。三是保障资金投入。创新资金扶持方式，加强对各类资金的统筹引导。发挥国家产融合作平台等作用，引导金融资源支持数字化发展。鼓励引导资本规范参与数字中国建设，构建社会资本有效参与的投融资体系。四是强化人才支撑。增强领导干部和公务员数字思维、数字认知、数字技能。统筹布局一批数字领域学科专业点，培养创新型、应用型、复合型人才。构建覆盖全民、城乡融合的数字素养与技能发展培育体系。五是营造良好氛围。推动高等学校、研究机构、企业等共同参与数字中国建设，建立一批数字中国研究基地。统筹开展数字中国建设综合试点工作，综合集成推进改革试验。办好数字中国建设峰会等重大活动，举办数字领域高规格国内国际系列赛事，推动数字化理念深入人心，营造全社会共同关注、积极参与数字中国建设的良好氛围。', NULL, NULL, 1, NULL, '2026-03-21 16:48:15', 10, 3),
(4, NULL, '关于加快公共数据资源开发利用的意见', '窗体顶端

窗体底端

首页 > 政策 > 中央文件

中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见

2024-10-09 17:56 来源： 新华社|

新华社北京10月9日电

中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见
（2024年9月21日）

各级党政机关、企事业单位依法履职或提供公共服务过程中产生的公共数据，是国家重要的基础性战略资源。为加快公共数据资源开发利用，充分释放公共数据要素潜能，推动高质量发展，经党中央、国务院同意，现提出如下意见。

一、总体要求

坚持以习近平新时代中国特色社会主义思想为指导，深入贯彻党的二十大和二十届二中、三中全会精神，完整准确全面贯彻新发展理念，统筹发展和安全，兼顾效率与公平，以促进公共数据合规高效流通使用为主线，以提高资源开发利用水平为目标，破除公共数据流通使用的体制性障碍、机制性梗阻，激发共享开放动力，优化公共数据资源配置，释放市场创新活力，充分发挥数据要素放大、叠加、倍增效应，为不断做强做优做大数字经济、构筑国家竞争新优势提供坚实支撑。

工作中要做到：坚持政府指导、市场驱动。加强政府指导和调控，更好发挥市场机制作用，有效扩大公共数据供给，提高公共数据资源配置效率和使用效益。坚持尊重规律、守正创新。鼓励各地区各部门因地制宜推动共享开放，探索开展依规授权运营，完善资源开发利用制度。坚持系统推进、高效协同。加强顶层设计，厘清部门和地方的管理边界，逐步形成权责清晰、条块协同的公共数据资源开发利用格局。坚持加快发展、维护安全。推动制度建设和能力建设相结合，将安全贯穿公共数据资源开发利用全过程，防范各种数据风险。

主要目标是：到2025年，公共数据资源开发利用制度规则初步建立，资源供给规模和质量明显提升，数据产品和服务不断丰富，重点行业、地区公共数据资源开发利用取得明显成效，培育一批数据要素型企业，公共数据资源要素作用初步显现。到2030年，公共数据资源开发利用制度规则更加成熟，资源开发利用体系全面建成，数据流通使用合规高效，公共数据在赋能实体经济、扩大消费需求、拓展投资空间、提升治理能力中的要素作用充分发挥。

二、深化数据要素配置改革，扩大公共数据资源供给

（一）统筹推进政务数据共享。完善政务数据目录，实行统一管理，推动实现“一数一源”，不断提升政务数据质量和管理水平。推动主动共享与按需共享相结合，完善政务数据共享责任清单，做好资源发布工作。强化已有数据共享平台的支撑作用，围绕“高效办成一件事”，推进跨层级、跨地域、跨系统、跨部门、跨业务政务数据共享和业务协同，不断增强群众和企业的获得感。

（二）有序推动公共数据开放。健全公共数据开放政策体系，明确公共数据开放的权责和范围，在维护国家数据安全、保护个人信息和商业秘密前提下，依法依规有序开放公共数据。完善公共数据开放平台，编制公布开放目录并动态更新，优先开放与民生紧密相关、社会需求迫切的数据，鼓励建立公共数据开放需求受理反馈机制，提高开放数据的完整性、准确性、及时性和机器可读性。

（三）鼓励探索公共数据授权运营。落实数据产权结构性分置制度要求，探索建立公共数据分类分级授权机制。加强对授权运营工作的统筹管理，明确数据管理机构，探索将授权运营纳入“三重一大”决策范围，明确授权条件、运营模式、运营期限、退出机制和安全管理责任，结合实际采用整体授权、分领域授权、依场景授权等模式，授权符合条件的运营机构开展公共数据资源开发、产品经营和技术服务。数据管理机构要履行行业监管职责，指导监督运营机构依法依规经营。运营机构要落实授权要求，规范运营行为，面向市场公平提供服务，严禁未经授权超范围使用数据。加快形成权责清晰、部省协同的授权运营格局。适时制定公共数据资源授权运营管理规定。

三、加强资源管理，规范公共数据授权运营

（四）健全资源管理制度。建立公共数据资源登记制度，依托政务数据目录，根据应用需求，编制形成公共数据资源目录，对纳入授权运营范围的公共数据资源实行登记管理。提高公共数据资源可用性，推动数据资源标准化、规范化建设，开展数据分类分级管理，强化数据源头治理和质量监督检查，实现数据质量可反馈、使用过程可追溯、数据异议可处置。

（五）完善运营监督。建立公共数据资源授权运营情况披露机制，按规定公开授权对象、内容、范围和时限等授权运营情况。运营机构应公开公共数据产品和服务能力清单，披露公共数据资源使用情况，接受社会监督。运营机构应依法依规在授权范围内开展业务，不得实施与其他经营主体达成垄断协议或滥用市场支配地位等垄断行为，不得实施不正当竞争行为。

（六）建立健全价格形成机制维护公共利益。发挥好价格政策的杠杆调节作用，加快建立符合公共数据要素特性的价格形成机制。指导推动用于公共治理、公益事业的公共数据产品和服务有条件无偿使用。用于产业发展、行业发展的公共数据经营性产品和服务，确需收费的，实行政府指导定价管理。

四、鼓励应用创新，推动数据产业健康发展

（七）丰富数据应用场景。在市场需求大、数据资源多的行业和领域，拓展应用场景，鼓励经营主体利用公共数据资源开发产品、提供服务。鼓励和支持企事业单位和社会组织有条件无偿使用公共数据开发公益产品，提供便民利民服务。支持人工智能政务服务大模型开发、训练和应用，提高公共服务和社会治理智能化水平。

（八）推动区域数据协作。落实区域重大战略、区域协调发展战略部署，鼓励京津冀、长三角、粤港澳大湾区以及成渝地区双城经济圈、长江中游城市群等创新推动公共数据资源开发利用，促进全国一体化数据市场发展，培育新兴产业。探索建立公共数据资源开发利用区域合作和利益调节机制，支持东中西部地区发挥比较优势，在数据存储、计算、服务等环节开展区域协作，共享数据要素红利。

（九）加强数据服务能力建设。加强数据基础设施建设，推动数据利用方式向共享汇聚和应用服务能力并重的方向转变。推进多元数据融合应用，丰富数据产品和服务。研究制订数据基础设施标准规范，推动设施互联、能力互通，推动构建协同高效的国家公共数据服务能力体系。鼓励有条件的地区探索公共数据产品和服务场内交易模式，统筹数据交易场所的规划布局，引导和规范数据交易场所健康发展。

（十）繁荣数据产业发展生态。将数据产业作为鼓励发展类纳入产业结构调整指导目录，支持数据采集标注、分析挖掘、流通使用、数据安全等技术创新应用，鼓励开发数据模型、数据核验、评价指数等多形式数据产品。围绕数据采存算管用，培育高水平数据要素型企业。聚焦算力网络和可信流通，支持数据基础设施企业发展。落实研发费用加计扣除、高新技术企业税收优惠等政策。支持数据行业协会、学会等社会团体和产业联盟发展，凝聚行业共识，加强行业自律，推动行业发展。

五、统筹发展和安全，营造开发利用良好环境

（十一）加大创新激励。明确公共数据管理和运营的责任边界，围绕强化管理职责优化机构编制资源配置。在有条件的地区和部门，按照管运适度分离的原则，在保障政务应用和公共服务的前提下，承担数据运营职责的事业单位可按照国家有关规定转企改制，试点成立行业性、区域性运营机构，并按照国有资产有关法律法规进行管理，符合要求的纳入经营性国有资产集中统一监管。研究制定支持运营机构发展的激励政策。

（十二）加强安全管理。强化数据安全和个人信息保护，加强对数据资源生产、加工使用、产品经营等开发利用全过程的监督和管理。建立健全分类分级、风险评估、监测预警、应急处置等工作体系，开展公共数据利用的安全风险评估和应用业务规范性审查。运营机构应依据有关法律法规和政策要求，履行数据安全主体责任，采取必要安全措施，保护公共数据安全。加强技术能力建设，提升数据汇聚关联风险识别和管控水平。依法依规予以保密的公共数据不予开放，严格管控未依法依规公开的原始公共数据直接进入市场。

（十三）鼓励先行先试。充分考虑数据领域未知变量，落实“三个区分开来”，鼓励和保护干部担当作为，营造鼓励创新、包容创新的干事创业氛围，支持在制度机制、依规授权、价格形成、收益分配等方面积极探索可行路径。充分认识数据规模利用的潜在风险，坚决防止以数谋私等“数据上的腐败”，坚持有错必纠、有过必改，对苗头性、倾向性问题早发现早纠正，对失误错误及时采取补救措施，维护公共数据安全。

六、强化组织实施

（十四）加强组织领导。坚持和加强党对数据工作的全面领导。在党中央集中统一领导下，各地区各部门要强化组织实施，结合实际抓好本意见贯彻落实。国务院办公厅强化工作协调，统筹推进政务数据共享工作。国家数据局加强工作统筹，动态掌握全国公共数据资源开发利用情况，及时协调解决工作中的重要问题。重要情况及时按程序向党中央、国务院请示报告。

（十五）强化资金保障。加大中央预算内投资对数据基础设施、数据安全能力建设的支持力度。各地区各部门可结合实际需要统筹安排数据产品和服务采购经费。鼓励各类金融机构创新产品和服务，加大对数据要素型企业和数据基础设施企业的融资支持力度。引导社会资本有序参与公共数据资源开发利用活动。

（十六）增强支撑能力。加快建立数据产权归属认定、市场交易、权益分配、利益保护制度。统筹数据领域标准体系建设管理，组织开展相关标准研制、宣传、执行和评价。依托国家重点研发计划、国家科技重大专项等，开展数据加密、可信流通、安全治理等关键技术研究和攻关。加强数据领域人才队伍建设，将提高做好数据工作的能力纳入干部教育培训内容。积极参与国际交流合作，推动公共数据国际治理规则、国际标准制定。

（十七）加强评价监督。各地区各部门可结合实际探索开展公共数据资源开发利用绩效考核，依法依规向审计机关开放公共数据资源目录和开发利用情况。鼓励开展公共数据资源开发利用成效评价和第三方评估，加强经验总结和宣传推广，营造良好氛围。', NULL, NULL, 1, NULL, '2026-03-21 16:48:15', 10, 4),
(5, NULL, '四川省数据条例', '首页 政府领导 机构职能 政务公开 政务服务 政民互动 走进四川
四川省数据条例
四川省第十三届人民代表大会常务委员会公告
（第127号）
《四川省数据条例》已由四川省第十三届人民代表大会常务委员会第三十八
次会议于2022年12月2日通过，现予公布，自2023年1月1日起施行。
四川省人民代表大会常务委员会
2022年12月2日
四川省数据条例
（2022年12月2日四川省第十三届人民代表大会常务委员会第三十八次会议通
过）
目录
第一章总则
第二章数据资源
第三章数据流通

第四章数据应用
第五章数据安全
第六章区域合作
第七章法律责任
第八章附则
第一章总则
第一条为了加强数据资源管理，规范数据处理活动，保护自然人、法人和
非法人组织的合法权益，保障数据安全，促进数据依法有序流通和应用，推动以
数据为关键要素的数字经济发展，根据《中华人民共和国数据安全法》、《中华
人民共和国个人信息保护法》等有关法律、行政法规，结合四川省实际，制定本
条例。
第二条四川省行政区域内数据资源管理、数据流通、数据应用、数据安全
和区域合作等活动，适用本条例。
第三条县级以上地方各级人民政府应当加强对数据工作的领导，统筹推进
数据管理工作，建立协调机制和考核评价机制，将数据开发利用和产业发展纳入
国民经济和社会发展规划，制定支持数据领域发展的政策措施，整合本行政区域
数据领域发展资源，培育数据要素市场，发挥数据在促进经济发展、服务改善民
生、完善社会治理等方面的作用。

第四条县级以上地方各级人民政府应当明确数据管理机构负责本行政区域
数据统筹管理、开发利用和监督检查，以及推进数据资源体系建设和数据要素市
场培育等工作。
第五条发展改革、经济和信息化等主管部门按照各自职责，做好数据领域
发展促进工作。
网信部门负责统筹协调个人信息保护、网络数据安全和相关监管工作。公
安、国家安全机关依法在各自职责范围内负责数据安全相关工作。
各行业主管部门在各自职责范围内负责本行业、本领域的数据相关工作。
第六条县级以上地方各级人民政府应当加强数字基础设施建设的统筹协
调，将数字基础设施的建设和布局纳入国土空间规划，结合实际编制和实施数字
基础设施建设规划，并与交通运输、能源、水利、市政等基础设施专项规划相衔
接。
县级以上地方各级人民政府及其有关部门应当提升电子政务云、电子政务外
网等的服务能力，建设新一代通信网络、新型数据中心等重大基础设施，建立完
善网络、存储、计算、安全等数字基础设施。
第七条省人民政府标准化行政主管部门应当会同有关部门加强数据标准体
系建设和管理，制定完善并推广数据收集、共享、开放、应用等标准规范。
鼓励企业、科研机构和社会团体等参与制定数据国家标准、行业标准、团体
标准和地方标准等技术规范。

第八条数据相关行业组织应当建立健全行业规范，主动接受相关主管部门
的指导、监督，加强行业自律，推动行业诚信建设，监督、引导从业者依法开展
数据相关活动，促进行业健康发展。
第九条自然人的个人信息受法律保护，任何组织、个人不得侵害自然人的
个人信息权益。
履行个人信息保护和数据安全管理职责的部门应当建立数据监管相关的投
诉、举报制度，收到投诉、举报后及时依法处理，并对相关信息予以保密。
第二章数据资源
第十条省数据管理机构应当会同相关部门按照国家规定，建立全省统一的
公共数据资源体系，推进公共数据资源依法采集汇聚、加工处理、共享开放、创
新应用。
本条例所称公共数据，是指国家机关和法律、法规授权的具有管理公共事务
职能的组织（以下统称政务部门）为履行法定职责收集、产生的政务数据，以及
医疗、教育、供水、供电、供气、通信、文化旅游、体育、交通运输、环境保护
等公共企业事业单位（以下统称公共服务组织）在提供公共服务过程中收集、产
生的涉及公共利益的公共服务数据。
第十一条省数据管理机构负责推动构建全省公共数据资源中心体系和建设
公共数据资源管理平台，支撑公共数据汇聚、存储、共享、开放和安全管理等工
作。

政务部门和财政资金保障运行的公共服务组织不得新建跨部门、跨层级的公
共数据资源管理平台；已经建成的，应当按照规定进行整合。
第十二条省数据管理机构会同有关部门，按照国家有关公共数据分类分级
的要求，制定本省公共数据分类分级规则，促进公共数据分类分级管理。
省有关行业主管部门可以根据国家和省公共数据分类分级的相关规定，制定
本行业公共数据分类分级实施细则。
第十三条省数据管理机构应当会同有关部门建立和完善人口、法人、自然
资源和空间地理、社会信用信息、电子证照等基础数据库，以及宏观经济、政务
服务、社会治理、生态环境、民生保障等跨地区、跨部门、跨层级主题数据库。
第十四条公共数据实行目录化管理。省数据管理机构应当统筹推进全省公
共数据目录管理，制定统一的目录编制指南，组织编制、发布全省公共数据目录
并动态更新。
市（州）、县（市、区）数据管理机构应当按照目录编制指南，组织编制本
级公共数据子目录，报上一级数据管理机构审核。
政务部门和公共服务组织应当按照目录编制指南，编制本单位公共数据子目
录，报同级数据管理机构审核。
第十五条政务部门和公共服务组织应当按照一项数据有且只有一个法定数
源部门的原则，依照法定的权限、程序和标准规范收集公共数据，不得超出履行
法定职责所必需的范围和限度。

除法律、行政法规另有规定外，可以通过共享获取的公共数据，不得重复收
集。
收集公共数据应当分别以下列号码或者代码作为必要标识：
（一）公民身份号码或者个人其他有效身份证件号码；
（二）法人统一社会信用代码；
（三）非法人组织统一社会信用代码或者其他识别代码；
（四）依据相关数据标准确定的代码标识。
政务部门和公共服务组织收集数据时，已经通过有效身份证件验明身份的，
不得强制通过收集指纹、虹膜、人脸等生物识别信息重复验证。法律、行政法规
另有规定的除外。
第十六条在商场、超市、公园、景区、公共文化体育场馆、宾馆等公共场
所，以及居住小区、商务楼宇等公共区域，安装图像收集、个人身份识别设备，
应当以维护公共安全为目的，遵守国家有关规定，并设置显著标识，不得以图像
采集、个人身份识别技术作为出入该场所或者区域的唯一验证方式。
所收集的个人图像、身份识别信息只能用于维护公共安全的目的；取得个人
授权的除外。
第十七条发生突发事件时，县级以上地方各级人民政府及其有关部门可以
按照应对突发事件有关法律、法规规定，要求相关自然人、法人和非法人组织提
供应对突发事件所必需的数据。
要求自然人、法人和非法人组织提供前款所需数据的，应当依照法定条件和
程序进行，并明确告知数据使用的目的、范围、方式和期限。对在履行职责中知

悉的个人隐私、个人信息、商业秘密、保密商务信息等数据应当依法予以保密，
不得泄露或者非法向他人提供。使用期限届满后，应当依法及时对数据进行删
除、封存、匿名化处理等方式妥善处理，并关停相关数据应用。
第十八条政务部门和财政资金保障运行的公共服务组织为依法履行职责或
者提供公共服务需要的数据，不能通过共享方式获取的，经同级数据管理机构确
认后可以通过采购获取。
第十九条政务部门和公共服务组织应当依据公共数据目录，将本单位公共
数据汇聚至省、市（州）数据资源中心；依照法律、行政法规规定未能汇聚的数
据，应当经本级数据管理机构确认，并以适当方式进行数据共享和开放。
省公共数据资源中心汇聚的公共数据应当及时按照属地原则回流至市（州）
公共数据资源中心。市（州）公共数据资源中心应当为县（市、区）、乡（镇）
使用公共数据提供支撑。
第二十条省数据管理机构会同有关部门建立健全以下公共数据治理工作机
制：
（一）建立公共数据资源普查制度，编制公共数据资源清单，实现公共数据
资源统一管理；
（二）建立公共数据质量管控制度，实现问题数据可追溯、可定责，保证数
据及时、准确、完整；
（三）建立公共数据校核制度，自然人、法人和非法人组织发现涉及自身的
公共数据不准确、不完整的，可以向政务部门或者公共服务组织提出校核申请，
相关政务部门、公共服务组织应当及时依法处理并反馈；

（四）建立公共数据使用情况统计反馈制度，由省数据管理机构统计并定期
向数据来源部门反馈公共数据的归集、使用、交易等情况。
第二十一条自然人、法人和非法人组织可以通过合法、正当的方式收集非
公共数据。收集已公开的非公共数据，不得违反法律、行政法规的规定，不得侵
犯他人的合法权益。法律、行政法规对非公共数据收集的目的和范围有规定的，
从其规定。
自然人、法人和非法人组织在收集非公共数据时，不得实施下列侵害其他市
场主体合法权益的行为：
（一）使用非法手段获取其他市场主体的数据；
（二）利用非法收集的其他市场主体数据提供替代性产品或者服务；
（三）法律、行政法规规定禁止的其他行为。
第三章数据流通
第二十二条省数据管理机构应当会同相关部门按照国家要求，深化数据要
素市场化配置改革，培育公平、开放、有序、诚信的数据要素市场，推进公共数
据共享、开放、授权运营，规范数据交易，促进数据要素依法有序流通。
第二十三条公共数据以共享为原则、不共享为例外。
公共数据共享，是指政务部门和公共服务组织为履行法定职责或者提供公共
服务需要，依法使用其他政务部门和公共服务组织的公共数据，以及为其他政务
部门和公共服务组织提供公共数据的行为。
公共数据按照共享属性分为无条件共享、有条件共享、不予共享三类。

政务部门和公共服务组织应当按照国家和省有关规定对收集、产生的公共数
据进行评估，科学合理确定共享属性，并定期更新。列入有条件共享数据的，应
当说明理由并明确共享条件；列入不予共享数据的，应当提供明确的法律、法
规、规章或者国家有关规定。
第二十四条政务部门和公共服务组织需要获取无条件共享公共数据的，可
以通过共享平台直接获取；需要获取有条件共享公共数据的，应当通过共享平台
向本级数据管理机构提出共享申请，并列明理由、依据、用途等。
数据管理机构应当自收到申请之日起五个工作日内依据数据共享目录予以答
复，可共享的，应当予以共享；不可共享的，应当说明理由，并提供依据；不能
确定能否共享的，答复期限可以延长五个工作日，并应当通过平台向数据提供单
位征求是否共享。
数据提供单位应当在三个工作日内答复数据管理机构，同意共享的，数据管
理机构应当在两个工作日内予以共享；不同意共享的，应当说明理由，数据管理
机构应当在两个工作日内完成审核，并告知数据申请单位。
第二十五条政务部门和公共服务组织应当在授权使用的方式、范围和期限
内，使用通过共享获取的公共数据，不得用于本单位履行职责之外的其他目的。
第二十六条政务部门和公共服务组织向社会开放公共数据，应当遵循公
正、公平、便民、安全的原则。公共数据开放，不得收取任何费用。
公共数据开放，是指政务部门和公共服务组织向社会依法提供公共数据的行
为。
公共数据按照开放属性分为无条件开放、有条件开放、不予开放三类。

法律、行政法规规定不得开放以及开放后可能危及国家安全、危害公共利
益、损害民事权益的公共数据，列入不予开放类；需要依法授权向特定自然人、
法人和非法人组织开放的公共数据，列入有条件开放类；其他公共数据列入无条
件开放类。法律、行政法规另有规定的除外。
县级以上地方各级人民政府应当依法最大限度向社会有序开放公共数据，并
推动企业登记监管、卫生、交通运输、气象等高价值数据优先开放。
第二十七条省数据管理机构根据国家和省有关公共数据分类分级要求，组
织编制全省公共数据开放目录和相关责任清单。市（州）数据管理机构可以组织
编制本行政区域公共数据开放子目录。
第二十八条自然人、法人和非法人组织需要获取无条件开放公共数据的，
可以通过开放平台直接获取；需要获取有条件开放公共数据的，应当依据目录通
过开放平台向数据管理机构提出开放申请，并列明理由、依据、用途等。
数据管理机构应当自收到开放申请之日起五个工作日内依据开放目录予以答
复，可开放的，应当予以开放；不同意开放的，应当说明理由，并提供依据；', NULL, NULL, 1, NULL, '2026-03-21 16:48:15', 9, 5);

-- 表: permission_configs
DROP TABLE IF EXISTS `permission_configs`;
CREATE TABLE `permission_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置键',
  `config_value` text COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '配置描述',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permission_configs` VALUES (1, 'user_eval_limit', '3', '普通用户每月评估次数', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(2, 'user_knowledge_view', '0', '普通用户知识库查看权限', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(3, 'user_report_view', '1', '普通用户报告查看权限', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(4, 'user_report_download', '0', '普通用户报告下载权限', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(5, 'vip_eval_limit', '30', 'VIP用户每月评估次数', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(6, 'vip_knowledge_view', '1', 'VIP知识库查看权限', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(7, 'vip_report_download', '1', 'VIP报告下载权限', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(8, 'vip_priority_queue', '1', 'VIP优先队列权限', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(9, 'vip_report_save_limit', '30', 'VIP历史报告保存数', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(10, 'vip_default_monthly_days', '30', '月度VIP默认天数', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(11, 'vip_default_yearly_days', '365', '年度VIP默认天数', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(12, 'vip_expire_action', 'keep', 'VIP到期处理策略', '2026-03-21 17:49:54', '2026-03-21 17:49:54'),
(13, 'vip_renewal_reminder_days', '3', 'VIP续费提醒天数', '2026-03-21 17:49:54', '2026-03-21 17:49:54');

-- 表: rule_configs
DROP TABLE IF EXISTS `rule_configs`;
CREATE TABLE `rule_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dimension_code` varchar(50) NOT NULL,
  `rule_name` varchar(200) NOT NULL,
  `logic_expression` text NOT NULL,
  `weight` decimal(5,2) DEFAULT '0.00',
  `risk_threshold` decimal(5,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `source_type` varchar(50) DEFAULT 'manual',
  `version` varchar(20) DEFAULT '1.0',
  `ai_prompt_context` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rule_description` text,
  `is_deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `rule_configs` VALUES (1, 'C', '数据来源合规性', '100 - (30 if user_auth == ''无明确协议'' else 15 if user_auth == ''有概括性协议'' else 0)', '5.00', '60.00', 1, 'manual', '18.0', NULL, '2026-03-12 17:59:41', '2026-03-21 16:28:45', NULL, 0),
(2, 'C', '敏感数据处理', '100 - (25 if sensitive_data == ''明文存储'' else 10 if sensitive_data == ''加密存储'' else 0)', '5.00', '60.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(3, 'C', '数据安全措施', '100 - (15 if data_encrypt == ''否'' else 5 if data_encrypt == ''部分加密'' else 0)', '4.00', '55.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(4, 'C', '隐私政策合规', '100 - (10 if data_policy == ''否'' else 0)', '3.00', '50.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(5, 'C', '数据跨境传输', '100 - (20 if ''跨境'' in str(data_source) else 0)', '4.00', '60.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(6, 'C', '数据留存管理', '100 - (20 if compliance_history == ''有过行政处罚'' else 10 if compliance_history == ''有过整改记录'' else 0)', '4.00', '50.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(7, 'C', '安全认证情况', 'min(100, 50 + len(security_cert) * 20)', '3.00', '50.00', 1, 'manual', '1', NULL, '2026-03-13 21:03:15', '2026-03-13 21:09:18', NULL, 0),
(8, 'Q', '数据质量管理', '100 - (20 if update_frequency == ''静态一次性'' else 10 if update_frequency == ''月级'' else 5 if update_frequency == ''周级'' else 0)', '4.00', '50.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(9, 'Q', '元数据完整性', 'min(100, max(0, completeness))', '4.00', '50.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(10, 'Q', '数据标准化程度', '100 - (10 if len(data_format) < 2 else 0)', '3.00', '45.00', 1, 'manual', '3.0', NULL, '2026-03-12 17:59:41', '2026-03-20 15:55:06', NULL, 0),
(11, 'Q', '数据类型多样性', 'min(100, 40 + len(data_type) * 15)', '3.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 21:03:15', '2026-03-13 21:09:18', NULL, 0),
(12, 'O', '数据权属确认', '70 + (30 if ''数据资产登记证书'' in rights_cert else 0)', '5.00', '60.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(13, 'O', '使用权界定', '70 + (30 if ''数据知识产权登记证书'' in rights_cert else 0)', '3.00', '45.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(14, 'O', '收益权分配', '70 + (30 if ''政府授权运营书'' in rights_cert else 0)', '3.00', '45.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(15, 'O', '数据独创性评估', 'min(100, 50 + (30 if originality == ''高'' else 15 if originality == ''中'' else 0))', '3.00', '50.00', 1, 'manual', '1', NULL, '2026-03-13 21:03:15', '2026-03-13 21:09:18', NULL, 0),
(16, 'V', '数据应用场景', 'min(100, 50 + len(application_scenario) * 15)', '4.00', '45.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(17, 'V', '数据价值评估', 'min(100, 50 + len(asset_purpose) * 10)', '4.00', '50.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(18, 'V', '数据变现能力', 'min(100, 60 + (10 if data_product else 0))', '3.00', '40.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(19, 'V', '数据规模价值', 'min(100, 30 + (30 if data_volume_records == ''千万级以上'' else 20 if data_volume_records == ''百万级'' else 10 if data_volume_records == ''十万级'' else 0))', '3.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 21:03:15', '2026-03-13 21:09:18', NULL, 0),
(20, 'S', '合规成本核算', '100 - (30 if cost_accounting == ''完全混合'' else 10 if cost_accounting == ''有部分分摊'' else 0)', '3.00', '45.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(21, 'S', '存储成本计量', 'min(100, 50 + min(cost_input / 10, 50))', '4.00', '50.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(22, 'S', '运维成本统计', 'min(100, 70 + (20 if cost_accounting == ''有独立项目核算'' else 0))', '3.00', '45.00', 1, 'manual', '1.0', NULL, '2026-03-12 17:59:41', '2026-03-13 21:09:18', NULL, 0),
(23, 'M', '数据治理组织', '100 - (30 if has_data_dept == ''否'' else 0)', '4.00', '50.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(24, 'M', '数据管理制度', 'min(100, 50 + (20 if data_policy == ''是'' else 0) + len(security_cert) * 10)', '4.00', '50.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(25, 'M', '数据质量监控', '100 - (25 if update_frequency == ''静态一次性'' else 10 if update_frequency == ''月级'' else 0)', '3.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(26, 'L', '数据共享能力', 'min(100, 40 + len(application_scenario) * 15)', '4.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(27, 'L', 'API服务能力', '100 - (30 if not data_product else 15 if len(data_product) < 2 else 0)', '4.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(28, 'L', '数据交易记录', 'min(100, 50 + (30 if commercial_plan == ''已有交易'' else 15 if commercial_plan == ''计划中'' else 0))', '3.00', '40.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(29, 'P', '数据增长趋势', 'min(100, 60 + (20 if update_frequency == ''实时'' else 10 if update_frequency == ''日级'' else 0))', '4.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(30, 'P', '技术创新能力', 'min(100, 50 + min(ip_patent + ip_copyright, 50))', '4.00', '45.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0),
(31, 'P', '市场拓展空间', '100 - (30 if len(application_scenario) < 2 else 15 if len(application_scenario) < 4 else 0)', '3.00', '40.00', 1, 'manual', '1', NULL, '2026-03-13 20:51:05', '2026-03-13 21:09:18', NULL, 0);

-- 表: system_configs
DROP TABLE IF EXISTS `system_configs`;
CREATE TABLE `system_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_configs` VALUES (1, 'free_daily_eval_limit', '3', '普通用户每日评估次数限制'),
(2, 'vip_default_days', '30', 'VIP默认开通天数'),
(3, 'free_report_retention_days', '7', '普通用户报告保留天数'),
(4, 'vip_report_retention_days', '36500', 'VIP用户报告保留天数（永久=36500天）'),
(5, 'enable_vip_export', 'true', '是否启用VIP导出功能'),
(6, 'enable_ai_analysis', 'true', '是否启用AI分析功能'),
(7, 'system_name', '数维数据管家系统', '系统名称'),
(8, 'contact_email', 'support@example.com', '联系邮箱'),
(9, 'user_eval_limit', '5', '普通用户每月评估次数'),
(10, 'user_knowledge_view', '0', '普通用户知识库查看权限'),
(11, 'user_report_view', '1', '普通用户报告查看权限'),
(12, 'user_report_download', '0', '普通用户报告下载权限'),
(13, 'vip_eval_limit', '30', 'VIP用户每月评估次数'),
(14, 'vip_knowledge_view', '1', 'VIP知识库查看权限'),
(15, 'vip_report_download', '1', 'VIP报告下载权限'),
(16, 'vip_priority_queue', '1', 'VIP优先队列权限'),
(17, 'vip_report_save_limit', '30', 'VIP历史报告保存数'),
(18, 'vip_default_monthly_days', '30', '月度VIP默认天数'),
(19, 'vip_default_yearly_days', '365', '年度VIP默认天数'),
(20, 'vip_expire_action', 'keep', 'VIP到期处理策略'),
(21, 'vip_renewal_reminder_days', '3', 'VIP续费提醒天数');

-- 表: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '?? ID',
  `username` varchar(50) NOT NULL COMMENT '???',
  `password_hash` varchar(255) NOT NULL COMMENT '????',
  `email` varchar(100) DEFAULT NULL COMMENT '??',
  `phone` varchar(20) DEFAULT NULL COMMENT '???',
  `referrer_code` varchar(20) DEFAULT NULL COMMENT '??????????',
  `channel_id` int DEFAULT NULL COMMENT '???? ID',
  `user_type` enum('client','admin','channel') DEFAULT 'client' COMMENT '????',
  `is_vip` tinyint(1) DEFAULT '0' COMMENT '?? VIP',
  `vip_expire_date` date DEFAULT NULL COMMENT 'VIP ????',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '????',
  `last_login_at` timestamp NULL DEFAULT NULL COMMENT '??????',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '????',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '????',
  `daily_eval_count` int DEFAULT '0',
  `daily_eval_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `idx_email_unique` (`email`),
  KEY `channel_id` (`channel_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='???';

INSERT INTO `users` VALUES (1, 'admin', '$2b$12$/SENdBfXhTngcCjxVUkNgeZIaMFy6aRXgwk8ClM9RsyrcRkeohA1O', 'admin@shuwei.com', '13800000000', NULL, NULL, 'admin', 0, NULL, 1, '2026-03-21 18:40:29', '2026-03-12 20:30:49', '2026-03-21 18:40:29', 0, '2026-03-17'),
(2, 'test_user', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYzS3MebAJu', 'test@test.com', '13800000001', 'OFFICIAL', 1, 'client', 0, NULL, 1, NULL, '2026-03-12 20:30:49', '2026-03-14 19:36:09', 0, NULL),
(3, 'vip_user', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYzS3MebAJu', 'vip@test.com', '13800000002', 'PARTNER_A', 2, 'client', 1, '2026-04-21', 1, NULL, '2026-03-12 20:30:49', '2026-03-21 18:41:55', 0, NULL),
(4, 'tuxiaowei520', '$2b$12$1hCw3OXoCW9r3h5GVYQWEeaLiF7d4F6XXuuAnOCBm/AjuWQyqsD6O', 'tuxiaowei520@163.com', '13982274410', NULL, NULL, 'client', 1, '2026-04-21', 1, '2026-03-19 19:15:37', '2026-03-14 12:33:08', '2026-03-21 18:20:45', 1, '2026-03-15'),
(5, 'tuxiaowei888', '$2b$12$duaFT2rI0ArN47TwnY2pNOqmn9oO.sRht83t4mQLCuJbMDCHSF8ae', 'tuxiaowei888@shuwei.com', '13982274410', NULL, NULL, 'client', 0, NULL, 1, '2026-03-19 19:24:23', '2026-03-14 19:52:18', '2026-03-21 18:33:23', 0, '2026-03-15');
